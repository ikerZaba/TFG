package com.example.izinventory;


import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.budiyev.android.codescanner.CodeScanner;
import com.budiyev.android.codescanner.CodeScannerView;
import com.budiyev.android.codescanner.DecodeCallback;
import com.google.zxing.Result;

public class QRScannerActivity extends Activity {
    CodeScanner codeScanner;
    Aplication app;



    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrscanner);
        permissionCheck();
        CodeScannerView codeScannerView = findViewById(R.id.QRscanner);
        codeScanner = new CodeScanner(this, codeScannerView);

        codeScanner.setDecodeCallback(new DecodeCallback() {
            @Override
            public void onDecoded(@NonNull Result result) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        app = (Aplication) getApplicationContext();
                        String information = result.getText();

                        //Information format id: #, container: #-X-#
                        String[] parts = information.split(",");
                        //int shipmentID = Integer.parseInt(parts[0].split(":")[1]);
                        String containerCode = parts[1].split(":")[1];
                        //because the resulting string contains an space at the beginning
                        containerCode = containerCode.replaceAll(" ","");
                        Container container = app.getContainerByCode(containerCode);

                        if(container != null){
                            Bundle bundle = new Bundle();
                            bundle.putString("code",container.getCode());
                            bundle.putInt("maxweight",container.getMaxWeight());
                            bundle.putInt("currentweight",container.getCurrentWeight());
                            if(container.getProduct()!=null) bundle.putString("content",container.getProduct());
                            else bundle.putString("content","empty");

                            Intent intent = new Intent(getApplicationContext(), ContainerInfoActivity.class);
                            intent.putExtras(bundle);
                            startActivity(intent);
                            finish();
                        }
                        else{
                            System.out.println("Container not found");;
                        }
                    }
                });
            }
        });

        codeScannerView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                codeScanner.startPreview();
            }
        });

        ImageButton goback = findViewById(R.id.goBack);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                finish();
            }
        });

    }
    @Override
    protected void onResume() {
        super.onResume();
        codeScanner.startPreview();
    }

    @Override
    protected void onPause() {
        super.onPause();
        codeScanner.startPreview();
    }

    public void permissionCheck(){
        if(checkSelfPermission(Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.CAMERA},12);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode!=12){
            permissionCheck();
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }
}
