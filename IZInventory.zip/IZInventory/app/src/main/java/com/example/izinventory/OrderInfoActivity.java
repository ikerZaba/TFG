package com.example.izinventory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class OrderInfoActivity extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info_order);
        TextView label = (TextView) findViewById(R.id.textView);
        Bundle bundle = getIntent().getExtras();
        int shipmentID = bundle.getInt("_id");
        String product = bundle.getString("product");
        String company = bundle.getString("company");
        String dateOfArrival = bundle.getString("date");
        int weight = bundle.getInt("weight");
        String status = bundle.getString("status");

        label.setText("\nProduct:"+product);
        label.append("\nCompany:"+company);
        label.append("\nWeight: "+weight+"kg\n");
        label.append("\nDate of arrival: "+dateOfArrival);
        label.append("\nStatus: "+status);

        Button notify = (Button) findViewById(R.id.buttonNotifyArrival);
        //don't show the button if the shipment has already arrived
        if(status.compareTo("ARRIVED")==0){
            notify.setVisibility(View.INVISIBLE);
        }
        notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(status.compareTo("ARRIVED")!=0){
                    Bundle bundle = new Bundle();
                    bundle.putInt("_id",shipmentID);
                    Intent intent = new Intent(getApplicationContext(), FillContainerActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });

        Button goback = (Button) findViewById(R.id.button4);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
