package com.example.izinventory;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;

import java.util.ArrayList;

public class ListAdapterOrders extends ArrayAdapter<Order> {
    Context context;
    public ListAdapterOrders(@NonNull Context context, ArrayList<Order> data) {
        super(context, R.layout.order_list_item, data);
        this.context = context;
    }

    @NonNull
    public View getView(int position, @Nullable View view, @NonNull ViewGroup parent) {
        Order order = getItem(position);

        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.order_list_item,parent,false);
        }

        ImageView listImage = view.findViewById(R.id.orderListImage);
        TextView productName = view.findViewById(R.id.orderListProductName);
        TextView companyName = view.findViewById(R.id.orderListCompanyName);
        TextView statusText = view.findViewById(R.id.orderStatus);
        TextView listDate = view.findViewById(R.id.orderDate);


        if(order.getStatus().compareTo("ARRIVED") == 0){
            listImage.setImageResource(R.drawable.ic_baseline_check_box_24);
            statusText.setTextColor(ContextCompat.getColor(context,R.color.main_blue));
        }
        else{
            listImage.setImageResource(R.drawable.shipping);
            statusText.setTextColor(ContextCompat.getColor(context,R.color.contrast_dark_red));
        }
        statusText.setText(order.getStatus());
        productName.setText(order.getProduct());
        companyName.setText("By: "+order.getCompany());
        listDate.setText(order.getDateOfArrival());

        return view;
    }

}
