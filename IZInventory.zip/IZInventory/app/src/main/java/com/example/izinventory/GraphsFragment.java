package com.example.izinventory;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class GraphsFragment extends Fragment {
    Aplication app;
    PieChart ordersPieChart;
    PieChart salesPieChart;
    BarChart salesBarChart;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View contentView = inflater.inflate(R.layout.fragment_graphs, container, false);
        app = (Aplication) getActivity().getApplicationContext();

        //ORDERS PIE CHART
        ordersPieChart = contentView.findViewById(R.id.ordersPieChart);
        ordersPieChart.setUsePercentValues(false);
        ordersPieChart.setDrawHoleEnabled(false);
        ordersPieChart.getDescription().setEnabled(false);
        ordersPieChart.setDrawEntryLabels(false);

        ArrayList<PieEntry> yValuesOrders = new ArrayList<>();

        int arrivedOrders = app.getArrivedOrderNumber();
        int pendingOrders = app.getNotArrivedOrderNumber();

        yValuesOrders.add(new PieEntry(arrivedOrders,"Arrived"));
        yValuesOrders.add(new PieEntry(pendingOrders,"Not Arrived"));

        PieDataSet dataSetOrders = new PieDataSet(yValuesOrders, "ORDERS");
        dataSetOrders.setColors(ColorTemplate.LIBERTY_COLORS);
        dataSetOrders.setDrawValues(true);

        ordersPieChart.setData(new PieData(dataSetOrders));

        //SALES PIE CHART
        salesPieChart = contentView.findViewById(R.id.salesPieChart);
        salesPieChart.setUsePercentValues(false);
        salesPieChart.setDrawHoleEnabled(false);
        salesPieChart.getDescription().setEnabled(false);
        salesPieChart.setDrawEntryLabels(false);

        ArrayList<PieEntry> yValuesSales = new ArrayList<>();

        int doneSales = app.getDoneSaleNumber();
        int pendingSales = app.getNotDoneSaleNumber();

        yValuesSales.add(new PieEntry(doneSales,"Done"));
        yValuesSales.add(new PieEntry(pendingSales,"Not Done"));

        PieDataSet dataSetSales = new PieDataSet(yValuesSales, "SALES");
        dataSetOrders.setColors(ColorTemplate.LIBERTY_COLORS);
        dataSetOrders.setDrawValues(true);

        salesPieChart.setData(new PieData(dataSetSales));

        //SALES BAR CHART
        salesBarChart = contentView.findViewById(R.id.salesBarChart);
        salesBarChart.getAxisRight().setDrawLabels(false);

        ArrayList<BarEntry> barEntries = new ArrayList<>();

        barEntries.add(new BarEntry(0,app.getSalesPerDayOfTheWeek(Calendar.MONDAY)));
        barEntries.add(new BarEntry(1,app.getSalesPerDayOfTheWeek(Calendar.TUESDAY)));
        barEntries.add(new BarEntry(2,app.getSalesPerDayOfTheWeek(Calendar.WEDNESDAY)));
        barEntries.add(new BarEntry(3,app.getSalesPerDayOfTheWeek(Calendar.THURSDAY)));
        barEntries.add(new BarEntry(4,app.getSalesPerDayOfTheWeek(Calendar.FRIDAY)));
        barEntries.add(new BarEntry(5,app.getSalesPerDayOfTheWeek(Calendar.SATURDAY)));

        salesBarChart.getAxisLeft().setAxisMaximum(20f);
        salesBarChart.getAxisLeft().setAxisMinimum(0f);
        salesBarChart.getAxisLeft().setAxisLineWidth(1f);
        salesBarChart.getAxisLeft().setAxisLineColor(R.color.black);
        salesBarChart.getAxisLeft().setLabelCount(4);

        List<String> xValues = Arrays.asList("Mon","Tue","Wed","Thu","Fri","Sat");
        salesBarChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(xValues));
        salesBarChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);

        BarDataSet dataSet = new BarDataSet(barEntries,"Sales per day");
        dataSet.setColors(ColorTemplate.PASTEL_COLORS);

        salesBarChart.getDescription().setEnabled(false);
        salesBarChart.invalidate();
        salesBarChart.setData(new BarData(dataSet));

        return contentView;
    }
}