package com.example.izinventory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
    Aplication app;
    TextView passText;
    EditText editTextPasswd;
    LinearLayout passLayout;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        app = (Aplication) getApplicationContext();
        passText = findViewById(R.id.textViewPasswd);
        editTextPasswd = findViewById(R.id.loginPasswd);
        passLayout = findViewById(R.id.passwordLayout);

        passLayout.setVisibility(View.INVISIBLE);
        //passText.setEnabled(false);
        //editTextPasswd.setEnabled(false);
    }

    public void login(View view){
        RadioButton buttonWorker = findViewById(R.id.radioButtonWorker);
        RadioButton buttonManager = findViewById(R.id.radioButtonManager);

        if(buttonManager.isChecked()){
            if(!passText.isEnabled()&&!editTextPasswd.isEnabled()){
                passText.setEnabled(true);
                editTextPasswd.setEnabled(true);
            }
            else{
                String passwd = editTextPasswd.getText().toString();
                if(passwd.isEmpty()){
                    Toast.makeText(this,"Fill the password please",Toast.LENGTH_SHORT).show();
                }
                else{
                    if(app.checkPassword(passwd)){
                        app.setUser("manager");
                    }
                    else{
                        Toast.makeText(this,"Incorrect password, try again",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
        else if(buttonWorker.isChecked()){
            app.setUser("worker");
        }
        else{
            Toast.makeText(this,"Select a user please",Toast.LENGTH_SHORT).show();
        }

        if(!app.getUser().isEmpty()){
            Intent intent = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(intent);
            finish();
        }
    }

    public void onRadioButtonClick(View view){
        RadioButton buttonWorker = findViewById(R.id.radioButtonWorker);
        RadioButton buttonManager = findViewById(R.id.radioButtonManager);

        boolean isSelected = ((RadioButton) view).isChecked();

        switch (view.getId()){
            case R.id.radioButtonWorker:
                if(isSelected){
                    buttonWorker.setTextColor(getResources().getColor(R.color.white));
                    buttonManager.setTextColor(getResources().getColor(R.color.main_dark_blue));
                    passLayout.setVisibility(View.INVISIBLE);
                    //passText.setEnabled(false);
                    //editTextPasswd.setEnabled(false);
                }

                break;
            case R.id.radioButtonManager:
                if(isSelected){
                    buttonManager.setTextColor(getResources().getColor(R.color.white));
                    buttonWorker.setTextColor(getResources().getColor(R.color.main_dark_blue));
                    passLayout.setVisibility(View.VISIBLE);
                    //passText.setEnabled(true);
                    //editTextPasswd.setEnabled(true);
                }
                break;
        }
    }
}
