package com.example.izinventory;

import android.app.Application;

import java.util.ArrayList;

public class Aplication extends Application {
    DBManager _manager;
    String user="";

    @Override
    public void onCreate() {
        super.onCreate();
        _manager = new DBManager(this);

    }

    public void setUser(String user){
        this.user = user;
    }

    public String getUser() {
        return user;
    }

    public ArrayList<Container> getContainerList() {
        return _manager.getContainerListDB();
    }

    public ArrayList<Order> getOrdersList() { return _manager.getOrderListDB();}

    public ArrayList<Sale> getSalesList() { return _manager.getSaleListDB();}

    public boolean orderArrival(int orderID) {
        return _manager.orderArrivalDB(orderID);
    }

    public boolean saleRegister(int saleID){
        return _manager.saleRegisterDB(saleID);
    }

    public Order searchOrderDB(int orderID) { return _manager.searchOrderDB(orderID);}

    public String findContainerAndFill(Order order) {
        return _manager.findContainerToFillDB(order);
    }

    public Container getContainerByCode(String code){
        return _manager.getContainerByCodeDB(code);
    }

    public int emptyContainer(String containerCode,int weight) {
        return _manager.emptyContainerDB(containerCode,weight);
    }

    public void errorSale(int saleID) {
        _manager.errorSaleDB(saleID);
    }
    public void errorOrder(int orderID) {
        _manager.errorOrderDB(orderID);
    }

    public boolean checkPassword(String passwd) {
        return _manager.checkPasswordDB(passwd);
    }

    public ArrayList<Order> getNotArrivedOrdersList() {
        return _manager.getNotArrivedOrderListDB();
    }

    public ArrayList<Order> getArrivedOrdersList() {
        return _manager.getArrivedOrderListDB();
    }

    public ArrayList<Sale> getNotDoneSaleList() {
        return _manager.getNotDoneSaleListDB();
    }

    public ArrayList<Sale> getDoneSaleList() {
        return _manager.getDoneSaleListDB();
    }

    public int getWarehouseSpace() {
        return _manager.getWarehouseSpaceDB();
    }

    public int getOccupiedWarehouseSpace() {
        return _manager.getOccupiedWarehouseSpaceDB();
    }

    public int getNumberOfContainers() {
        return _manager.getNumberOfContainersDB();
    }

    public int getEmptyContainers() {
        return _manager.getEmptyContainersDB();
    }

    public int getFullContainers() {
        return _manager.getFullContainersDB();
    }

    public int getLowStockContainers() {
        return _manager.getLowStockContainersDB();
    }

    public int getWeightOfNotArrivedOrders() {
        return _manager.getWeightOfNotArrivedOrdersDB();
    }

    public int getWeightOfNotDoneSales() {
        return _manager.getWeightOfNotDoneSalesDB();
    }

    public int getArrivedOrderNumber() {
        return _manager.getArrivedOrderListDB().size();
    }

    public int getNotArrivedOrderNumber() {
        return _manager.getNotArrivedOrderListDB().size();
    }

    public int getDoneSaleNumber() {
        return _manager.getDoneSaleListDB().size();
    }

    public int getNotDoneSaleNumber() {
        return _manager.getNotDoneSaleListDB().size();
    }

    public float getSalesPerDayOfTheWeek(int day) {
        return _manager.getSalesPerDayOfTheWeekDB(day);
    }
}