package com.example.izinventory;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.navigation.NavigationBarView;

public class MainActivity extends AppCompatActivity {

    BottomNavigationView bottomNavigationView;

    WarehouseFragment warehouseFragment = new WarehouseFragment();
    OrdersFragment ordersFragment = new OrdersFragment();
    SalesFragment salesFragment = new SalesFragment();
    InventoryFragment inventoryFragment = new InventoryFragment();
    GraphsFragment graphsFragment = new GraphsFragment();

    Intent intent;
    Aplication app;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        app = (Aplication) getApplicationContext();

        bottomNavigationView = findViewById(R.id.bottomNavigationBar);

        getSupportFragmentManager().beginTransaction().replace(R.id.container,warehouseFragment).commit();
        bottomNavigationView.setSelectedItemId(R.id.warehouse);

        if(app.getUser().compareTo("worker")==0){
            bottomNavigationView.getMenu().removeItem(R.id.inventory);
            bottomNavigationView.getMenu().removeItem(R.id.graphs);
        }

        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @SuppressLint("NonConstantResourceId")
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()){
                    case R.id.warehouse:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,warehouseFragment).commit();
                        getSupportActionBar().setTitle("IZInventory");
                        return true;
                    case R.id.orders:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container, ordersFragment).commit();
                        getSupportActionBar().setTitle("Orders");
                        return true;
                    case R.id.sales:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,salesFragment).commit();
                        getSupportActionBar().setTitle("Sales");
                        return true;
                    case R.id.inventory:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,inventoryFragment).commit();
                        getSupportActionBar().setTitle("Inventory");
                        return true;
                    case R.id.graphs:
                        getSupportFragmentManager().beginTransaction().replace(R.id.container,graphsFragment).commit();
                        getSupportActionBar().setTitle("Graphs");
                        return true;
                }
                return false;
            }
        });
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        if(app.getUser().compareTo("manager")==0){
            getMenuInflater().inflate(R.menu.manager_top_menu, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.addContainer:
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);

                return true;

            case R.id.newShipment:
                intent = new Intent(getApplicationContext(), AddOrderActivity.class);
                startActivity(intent);

                return true;

            case R.id.newSale:
                intent = new Intent(getApplicationContext(), MainActivity.class);
                startActivity(intent);
                Toast.makeText(MainActivity.this,"Select a container to sell its contents",Toast.LENGTH_SHORT).show();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}