package com.example.izinventory;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class OrdersFragment extends Fragment {
    View fragmentView;
    ArrayAdapter<Order> listAdapter;
    Aplication app;
    ArrayList<Order> orderList;
    ListView listView;
    int mode;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        fragmentView = inflater.inflate(R.layout.fragment_orders, container, false);

        app = (Aplication) getActivity().getApplicationContext();
        listView = fragmentView.findViewById(R.id.ordersListView);

        orderList = app.getOrdersList();
        listAdapter = new ListAdapterOrders(getActivity().getApplicationContext(), orderList);
        listView.setAdapter(listAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Order order = orderList.get(position);
                Bundle bundle = new Bundle();
                bundle.putInt("_id", order.get_id());
                bundle.putString("product", order.getProduct());
                bundle.putString("company", order.getCompany());
                bundle.putInt("weight", order.getWeight());
                bundle.putString("date", order.getDateOfArrival());
                bundle.putString("status", order.getStatus());

                Intent intent = new Intent(getActivity().getApplicationContext(), OrderInfoActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        CardView allCardView = fragmentView.findViewById(R.id.cardSortOrdersAll);
        TextView allTextView = fragmentView.findViewById(R.id.cardAllText);

        CardView notArrivedCardView = fragmentView.findViewById(R.id.cardSortOrdersNotArrived);
        TextView notArrivedTextView = fragmentView.findViewById(R.id.cardNotArrivedText);

        CardView arrivedCardView = fragmentView.findViewById(R.id.cardSortOrdersArrived);
        TextView arrivedTextView = fragmentView.findViewById(R.id.cardArrivedText);
        //Starts showing all orders
        mode = 0;
        allCardView.setCardBackgroundColor(getResources().getColor(R.color.main_deep_blue));
        allTextView.setTextColor(getResources().getColor(R.color.main_orange));
        notArrivedCardView.setCardBackgroundColor(getResources().getColor(R.color.main_orange));
        arrivedCardView.setCardBackgroundColor(getResources().getColor(R.color.main_orange));

        allCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mode != 0){
                    orderList = app.getOrdersList();
                    listAdapter = new ListAdapterOrders(getActivity().getApplicationContext(), orderList);
                    listView.setAdapter(listAdapter);
                    allCardView.setCardBackgroundColor(getResources().getColor(R.color.main_deep_blue));
                    allTextView.setTextColor(getResources().getColor(R.color.main_orange));


                    //return others to normal
                    if(mode == 2){
                        arrivedCardView.setCardBackgroundColor(getResources().getColor(R.color.main_orange));
                        arrivedTextView.setTextColor(getResources().getColor(R.color.black));
                    }
                    else{
                        notArrivedCardView.setCardBackgroundColor(getResources().getColor(R.color.main_orange));
                        notArrivedTextView.setTextColor(getResources().getColor(R.color.black));
                    }
                    mode = 0;
                }
            }
        });


        notArrivedCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mode != 1){
                    orderList = app.getNotArrivedOrdersList();
                    listAdapter = new ListAdapterOrders(getActivity().getApplicationContext(), orderList);
                    listView.setAdapter(listAdapter);
                    notArrivedCardView.setCardBackgroundColor(getResources().getColor(R.color.main_deep_blue));
                    notArrivedTextView.setTextColor(getResources().getColor(R.color.main_orange));

                    //return others to normal
                    if(mode==0){
                        allCardView.setCardBackgroundColor(getResources().getColor(R.color.main_orange));
                        allTextView.setTextColor(getResources().getColor(R.color.black));
                    }
                    else{
                        arrivedCardView.setCardBackgroundColor(getResources().getColor(R.color.main_orange));
                        arrivedTextView.setTextColor(getResources().getColor(R.color.black));
                    }

                    mode = 1;
                }
            }
        });


        arrivedCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mode != 2){
                    orderList = app.getArrivedOrdersList();
                    listAdapter = new ListAdapterOrders(getActivity().getApplicationContext(), orderList);
                    listView.setAdapter(listAdapter);
                    arrivedCardView.setCardBackgroundColor(getResources().getColor(R.color.main_deep_blue));
                    arrivedTextView.setTextColor(getResources().getColor(R.color.main_orange));


                    //return others to normal
                    if(mode==1){
                        notArrivedCardView.setCardBackgroundColor(getResources().getColor(R.color.main_orange));
                        notArrivedTextView.setTextColor(getResources().getColor(R.color.black));
                    }
                    else{
                        allCardView.setCardBackgroundColor(getResources().getColor(R.color.main_orange));
                        allTextView.setTextColor(getResources().getColor(R.color.black));
                    }

                    mode = 2;
                }
            }
        });

        return fragmentView;
    }
}