package com.example.izinventory;

public class Order {
    private int _id;
    private String dateOfArrival;
    private String product;
    private int weight;
    private String company;
    private String status;

    public Order(int _id, String dateOfArrival, String product, int weight, String company, String status) {
        this._id = _id;
        this.dateOfArrival = dateOfArrival;
        this.product = product;
        this.weight = weight;
        this.company = company;
        this.status = status;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getDateOfArrival() {
        return dateOfArrival;
    }

    public void setDateOfArrival(String dateOfArrival) {
        this.dateOfArrival = dateOfArrival;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public int getWeight() {
        return weight;
    }

    public void setWeight(int weight) {
        this.weight = weight;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
