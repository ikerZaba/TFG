package com.example.izinventory;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class InventoryFragment extends Fragment {
    Aplication app;
    Intent intent;
    PieChart pieChart;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View contentView = inflater.inflate(R.layout.fragment_inventory, container, false);
        app = (Aplication) getActivity().getApplicationContext();

        //WAREHOUSE CAPACITY
        pieChart = contentView.findViewById(R.id.capacityChart);
        pieChart.setUsePercentValues(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawEntryLabels(false);

        ArrayList<PieEntry> yValues = new ArrayList<>();

        int totalWarehouseSpace = app.getWarehouseSpace();
        int occupiedWarehouseSpace = app.getOccupiedWarehouseSpace();

        yValues.add(new PieEntry(occupiedWarehouseSpace,"Occupied"));
        yValues.add(new PieEntry(totalWarehouseSpace-occupiedWarehouseSpace,"Free"));

        PieDataSet dataSet = new PieDataSet(yValues, " ");
        dataSet.setColors(ColorTemplate.LIBERTY_COLORS);
        dataSet.setDrawValues(false);

        DecimalFormat df = new DecimalFormat("0.00");
        float perOccupied = (float) (occupiedWarehouseSpace*100.0/totalWarehouseSpace);
        pieChart.setCenterText(df.format(perOccupied)+"%");
        pieChart.setCenterTextSize(20);

        PieData pieData = new PieData(dataSet);

        pieChart.setData(pieData);

        //NUMBER OF CONTAINERS
        TextView textContainers = contentView.findViewById(R.id.numberOfContainers);

        textContainers.setText(String.valueOf(app.getNumberOfContainers()));

        Button addContainer = contentView.findViewById(R.id.addContainer);
        addContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getActivity().getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);
            }
        });
        //EMPTY CONTAINERS
        TextView textEmptyContainers = contentView.findViewById(R.id.emptyContainers);
        textEmptyContainers.setText(String.valueOf(app.getEmptyContainers()));
        //FULL CONTAINERS
        TextView textFullContainers = contentView.findViewById(R.id.fullContainers);
        textFullContainers.setText(String.valueOf(app.getFullContainers()));
        //LOW STOCK
        TextView textLowStockContainers = contentView.findViewById(R.id.lowStockContainers);
        textLowStockContainers.setText(String.valueOf(app.getLowStockContainers()));

        //INCOMING STOCK
        TextView textIncomingStock = contentView.findViewById(R.id.incomingStock);
        textIncomingStock.setText(String.valueOf(app.getWeightOfNotArrivedOrders())+"kg");
        //STOCK TO BE SOLD
        TextView textToBeSold = contentView.findViewById(R.id.stockToBeSold);
        textToBeSold.setText(String.valueOf(app.getWeightOfNotDoneSales())+"kg");
        return contentView;
    }
}