package com.example.izinventory;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class SaleInfoActivity extends Activity {
    Aplication app;
    int saleID = 0;
    String status = "";
    String container = "";
    int weight = 0;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infosale);
        app = (Aplication) getApplicationContext();
        TextView label = (TextView) findViewById(R.id.textView);
        Bundle bundle = getIntent().getExtras();
        saleID = bundle.getInt("_id");
        container = bundle.getString("container");
        String product = bundle.getString("product");
        String client = bundle.getString("client");
        String dateOfTransaction = bundle.getString("date");
        weight = bundle.getInt("weight");
        status = bundle.getString("status");
        int price = bundle.getInt("price");

        label.setText("\nFrom container code: "+container);
        label.append("\nProduct: "+product);
        label.append("\nClient: "+client);
        label.append("\nWeight taken: "+weight+"kg\n");
        label.append("\nDate of transaction: "+dateOfTransaction);
        label.append("\nPrice of transaction: "+price+"€");
        label.append("\nStatus: "+status);



        Button goback = (Button) findViewById(R.id.button4);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void completeSale(View view){
        if(status.compareTo("DONE")!=0){
            if(app.saleRegister(saleID)){
                //Toast.makeText(this,"Order arrival successfully registered",Toast.LENGTH_SHORT).show();
                int emptyContainerResult = app.emptyContainer(container,weight);
                switch(emptyContainerResult){
                    case 1:
                        Toast.makeText(this,"Container not found",Toast.LENGTH_LONG);
                        app.errorSale(saleID);
                        break;
                    case 2:
                        Toast.makeText(this,"Not enough product in the container",Toast.LENGTH_LONG);
                        app.errorSale(saleID);
                        break;
                    case 0:
                        Toast.makeText(this, "Sale DONE", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                }

            }
            else{
                Toast.makeText(this,"Unsuccessful, please try again",Toast.LENGTH_LONG).show();
            }
        }

    }
}
