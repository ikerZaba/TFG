package com.example.izinventory;

import android.content.Intent;
import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;


public class WarehouseFragment extends Fragment {

    ArrayAdapter<Container> itemsAdapter;
    Aplication app;
    ArrayList<Container> containerList;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View contentView = inflater.inflate(R.layout.fragment_warehouse, container, false);
        ListView listView = contentView.findViewById(R.id.warehouse_list_view);
        app = (Aplication) getActivity().getApplicationContext();

        containerList = app.getContainerList();
        itemsAdapter = new ListAdapterContainers(getActivity().getApplicationContext(),containerList);
        listView.setAdapter(itemsAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Container container = containerList.get(position);
                Bundle bundle = new Bundle();
                bundle.putString("code",container.getCode());
                bundle.putInt("maxweight",container.getMaxWeight());
                bundle.putInt("currentweight",container.getCurrentWeight());
                if(container.getProduct()!=null) bundle.putString("content",container.getProduct());
                else bundle.putString("content","empty");

                Intent intent = new Intent(getActivity().getApplicationContext(), ContainerInfoActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });


        ImageButton openScanner = contentView.findViewById(R.id.buttonScanQR);
        openScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getActivity().getApplicationContext(), QRScannerActivity.class);
                startActivity(intent);
            }
        });

        return contentView;
    }
}