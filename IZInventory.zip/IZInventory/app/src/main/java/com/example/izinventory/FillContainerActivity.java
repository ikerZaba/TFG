package com.example.izinventory;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

public class FillContainerActivity extends Activity {
    Aplication app;
    QRGenerator qrGenerator = new QRGenerator();
    PDFGenerator pdfGenerator = new PDFGenerator();
    int _idOrder;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fillcontainer);
        app = (Aplication) getApplicationContext();
        Bundle bundle = getIntent().getExtras();
        _idOrder = bundle.getInt("_id");
        TextView orderText = findViewById(R.id.orderIDText);
        orderText.setText("Order ID: "+_idOrder);

        ImageButton goback = findViewById(R.id.button5);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void fillContainer(View view){
        Order order = app.searchOrderDB(_idOrder);
        try {
            String containerCode = app.findContainerAndFill(order);
            System.out.println("Code: "+containerCode);
            if(!containerCode.isEmpty()){
                System.out.println("Registering order arrival");
                if(app.orderArrival(_idOrder)){
                    System.out.println("QRGenerator call");
                    Bitmap bitmap = qrGenerator.generateQRCode(_idOrder,containerCode);
                    try{
                        pdfGenerator.generatePDF(bitmap, order,containerCode);

                        Toast.makeText(this,"PDF successfully downloaded",Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                        startActivity(intent);
                        finish();
                    } catch (Exception e) {
                        Toast.makeText(this,"PDF creation ERROR",Toast.LENGTH_SHORT).show();
                        System.out.println("PDF creation ERROR");
                        app.errorOrder(_idOrder);
                    }
                }
                else{
                    Toast.makeText(this,"Error in the update of the order",Toast.LENGTH_SHORT).show();
                    System.out.println("Error in the update of the order");
                    app.emptyContainer(containerCode, order.getWeight());
                    app.errorOrder(_idOrder);
                }
            }
            else{
                Toast.makeText(this,"No container available",Toast.LENGTH_SHORT).show();
                System.out.println("No container available");
            }
        }catch (RuntimeException e){
            Toast.makeText(this,"Data base error",Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            app.errorOrder(_idOrder);
        }

    }
}
