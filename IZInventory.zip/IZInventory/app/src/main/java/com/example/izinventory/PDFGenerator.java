package com.example.izinventory;

import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.os.Environment;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class PDFGenerator {

    @SuppressLint("ResourceAsColor")
    public void generatePDF(Bitmap bitmap, Order order, String containerCode){
        PdfDocument pdfDocument = new PdfDocument();
        PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(1080,1920, 1).create();
        PdfDocument.Page page = pdfDocument.startPage(pageInfo);

        Canvas canvas = page.getCanvas();

        Paint paint = new Paint();
        paint.setColor(R.color.black);
        paint.setTextSize(20);

        String text = "Order ID: "+ order.get_id()+"\nProduct: "+ order.getProduct()+
                "\nDate Of Arrival: "+ order.getDateOfArrival()+"\nARRIVED\n Sent to container: "+containerCode;

        canvas.drawText(text,100,50, paint);

        //put the QR Code
        canvas.drawBitmap(bitmap,300,200,paint);

        pdfDocument.finishPage(page);

        File downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
        String fileName = containerCode+"_"+ order.get_id()+".pdf";
        File file = new File(downloadsDir, fileName);

        try{
            System.out.println("PDF generation starting...");
            FileOutputStream fos = new FileOutputStream(file);
            pdfDocument.writeTo(fos);
            System.out.println("PDF successfully created");
            pdfDocument.close();
            fos.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }
}
