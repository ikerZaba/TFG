package com.example.izinventory;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

public class AddOrderActivity extends Activity {
    DBManager _manager;
    int hour;
    int minute;
    int year;
    int month;
    int day;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addorder);
        _manager = new DBManager(this);

        EditText editTextDate = findViewById(R.id.editTextDateOfArrival);
        editTextDate.setEnabled(false);
        ImageButton dateButton = findViewById(R.id.buttonDate);
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog;
                dialog = new DatePickerDialog(AddOrderActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int pYear, int pickedMonth, int pickedDay) {
                        year = pYear;
                        month = pickedMonth+1;
                        day = pickedDay;

                        String dateString;

                        if(day<10){
                            dateString = "0"+day+"/";
                        }
                        else{
                            dateString = day+"/";
                        }
                        if(month<10){
                            dateString = dateString+"0"+month+"/";
                        }
                        else{
                            dateString = dateString+month+"/";
                        }

                        dateString=dateString+year;

                        editTextDate.setText(dateString);
                    }
                },year,month,day);
                dialog.show();
            }
        });

        EditText editTextTime = findViewById(R.id.editTextTimeOfArrival);
        editTextTime.setEnabled(false);
        ImageButton timeButton = findViewById(R.id.buttonTime);
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                hour = calendar.get(Calendar.HOUR_OF_DAY);
                minute = calendar.get(Calendar.MINUTE);

                TimePickerDialog dialog = new TimePickerDialog(AddOrderActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minuteOfHour) {
                        hour = hourOfDay;
                        minute = minuteOfHour;

                        String time;
                        if (hour < 10) {
                            time = "0" + hour + ":";
                        } else {
                            time = hour + ":";
                        }
                        if (minute < 10) {
                            time = time + "0" + minute;
                        } else {
                            time = time + minute;
                        }

                        editTextTime.setText(time);
                    }
                }, hour, minute, true);
                dialog.show();
            }
        });

        ImageButton goback = findViewById(R.id.button6);

        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void addOrder(View view) {
        EditText editTextDate = findViewById(R.id.editTextDateOfArrival);
        String stringDate = editTextDate.getText().toString();

        if (stringDate.isEmpty()) {
            Toast.makeText(this, "Please fill the date of arrival", Toast.LENGTH_SHORT).show();
        } else {
            EditText editTextTime = findViewById(R.id.editTextTimeOfArrival);
            String stringTime = editTextTime.getText().toString();
            if(stringTime.isEmpty()){
                Toast.makeText(this, "Please fill the time of arrival", Toast.LENGTH_SHORT).show();
            }
            else{
                EditText editTextProductName = findViewById(R.id.editTextProductName);
                String stringProduct = editTextProductName.getText().toString();

                if (stringProduct.isEmpty()) {
                    Toast.makeText(this, "Please fill the name of the product", Toast.LENGTH_SHORT).show();
                } else {
                    EditText editTextCompanyName = findViewById(R.id.editTextCompanyName);
                    String stringCompany = editTextCompanyName.getText().toString();

                    if (stringCompany.isEmpty()) {
                        Toast.makeText(this, "Please fill the name of the company", Toast.LENGTH_SHORT).show();
                    } else {
                        EditText editTextWeight = findViewById(R.id.editTextWeight);
                        String stringWeight = editTextWeight.getText().toString();

                        if (stringWeight.isEmpty()) {
                            Toast.makeText(this, "Please fill the weight of the order", Toast.LENGTH_SHORT).show();
                        } else {
                            if (!_manager.addOrderDB(stringDate+" "+stringTime, stringProduct, stringCompany, Integer.parseInt(stringWeight))) {
                                Toast.makeText(this, "Database error, please try again", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(this, "Order added to the list", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                    }
            }


            }

        }
    }
}
