package com.example.izinventory;

import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;


public class SalesFragment extends Fragment {

    View fragmentView;
    ArrayAdapter<Sale> listAdapter;
    Aplication app;
    ArrayList<Sale> saleList;
    ListView listView;
    int mode;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        fragmentView = inflater.inflate(R.layout.fragment_sales, container, false);

        app = (Aplication) getActivity().getApplicationContext();
        listView = fragmentView.findViewById(R.id.salesListView);

        saleList = app.getSalesList();
        listAdapter = new ListAdapterSales(getActivity().getApplicationContext(),saleList);
        listView.setAdapter(listAdapter);

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int position, long l) {
                Sale sale = saleList.get(position);
                Bundle bundle = new Bundle();
                bundle.putInt("_id",sale.get_id());
                bundle.putString("container",sale.getContainer());
                bundle.putString("product",sale.getProduct());
                bundle.putString("client",sale.getClient());
                bundle.putInt("weight",sale.getWeight());
                bundle.putString("date",sale.getDateOfSale());
                bundle.putString("status",sale.getStatus());
                bundle.putInt("price",sale.getPrice());

                Intent intent = new Intent(getActivity().getApplicationContext(), SaleInfoActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        CardView allCardView = fragmentView.findViewById(R.id.cardSortSalesAll);
        TextView allTextView = fragmentView.findViewById(R.id.cardAllText);

        CardView notDoneCardView = fragmentView.findViewById(R.id.cardSortSalesNotDone);
        TextView notDoneTextView = fragmentView.findViewById(R.id.cardNotDoneText);

        CardView doneCardView = fragmentView.findViewById(R.id.cardSortSalesDone);
        TextView doneTextView = fragmentView.findViewById(R.id.cardDoneText);
        //Starts showing all sales
        mode = 0;
        allCardView.setCardBackgroundColor(getResources().getColor(R.color.main_blue));
        allTextView.setTextColor(getResources().getColor(R.color.main_dark_blue));
        notDoneCardView.setCardBackgroundColor(getResources().getColor(R.color.main_dark_blue));
        doneCardView.setCardBackgroundColor(getResources().getColor(R.color.main_dark_blue));

        allCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mode != 0){
                    saleList = app.getSalesList();
                    listAdapter = new ListAdapterSales(getActivity().getApplicationContext(), saleList);
                    listView.setAdapter(listAdapter);
                    allCardView.setCardBackgroundColor(getResources().getColor(R.color.main_blue));
                    allTextView.setTextColor(getResources().getColor(R.color.main_dark_blue));


                    //return others to normal
                    if(mode == 2){
                        doneCardView.setCardBackgroundColor(getResources().getColor(R.color.main_dark_blue));
                        doneTextView.setTextColor(getResources().getColor(R.color.black));
                    }
                    else{
                        notDoneCardView.setCardBackgroundColor(getResources().getColor(R.color.main_dark_blue));
                        notDoneTextView.setTextColor(getResources().getColor(R.color.black));
                    }
                    mode = 0;
                }
            }
        });


        notDoneCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mode != 1){
                    saleList = app.getNotDoneSaleList();
                    listAdapter = new ListAdapterSales(getActivity().getApplicationContext(), saleList);
                    listView.setAdapter(listAdapter);
                    notDoneCardView.setCardBackgroundColor(getResources().getColor(R.color.main_blue));
                    notDoneTextView.setTextColor(getResources().getColor(R.color.main_dark_blue));

                    //return others to normal
                    if(mode==0){
                        allCardView.setCardBackgroundColor(getResources().getColor(R.color.main_dark_blue));
                        allTextView.setTextColor(getResources().getColor(R.color.black));
                    }
                    else{
                        doneCardView.setCardBackgroundColor(getResources().getColor(R.color.main_dark_blue));
                        doneTextView.setTextColor(getResources().getColor(R.color.black));
                    }

                    mode = 1;
                }
            }
        });


        doneCardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mode != 2){
                    saleList = app.getDoneSaleList();
                    listAdapter = new ListAdapterSales(getActivity().getApplicationContext(), saleList);
                    listView.setAdapter(listAdapter);
                    doneCardView.setCardBackgroundColor(getResources().getColor(R.color.main_blue));
                    doneTextView.setTextColor(getResources().getColor(R.color.main_dark_blue));


                    //return others to normal
                    if(mode==1){
                        notDoneCardView.setCardBackgroundColor(getResources().getColor(R.color.main_dark_blue));
                        notDoneTextView.setTextColor(getResources().getColor(R.color.black));
                    }
                    else{
                        allCardView.setCardBackgroundColor(getResources().getColor(R.color.main_dark_blue));
                        allTextView.setTextColor(getResources().getColor(R.color.black));
                    }

                    mode = 2;
                }
            }
        });

        return fragmentView;
    }
}