package com.example.menuapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.text.DecimalFormat;
import java.util.ArrayList;

public class InventoryActivity extends AppCompatActivity {
    Aplication app;
    Intent intent;
    PieChart pieChart;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);
        app = (Aplication) getApplicationContext();

        //WAREHOUSE CAPACITY
        pieChart = findViewById(R.id.capacityChart);
        pieChart.setUsePercentValues(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawEntryLabels(false);

        ArrayList<PieEntry> yValues = new ArrayList<>();

        int totalWarehouseSpace = app.getWarehouseSpace();
        int occupiedWarehouseSpace = app.getOccupiedWarehouseSpace();

        yValues.add(new PieEntry(occupiedWarehouseSpace,"Occupied"));
        yValues.add(new PieEntry(totalWarehouseSpace-occupiedWarehouseSpace,"Free"));

        PieDataSet dataSet = new PieDataSet(yValues, " ");
        dataSet.setColors(ColorTemplate.LIBERTY_COLORS);
        dataSet.setDrawValues(false);

        DecimalFormat df = new DecimalFormat("0.00");
        float perOccupied = (float) (occupiedWarehouseSpace*100.0/totalWarehouseSpace);
        pieChart.setCenterText(df.format(perOccupied)+"%");
        pieChart.setCenterTextSize(20);

        PieData pieData = new PieData(dataSet);

        pieChart.setData(pieData);

        //NUMBER OF CONTAINERS
        TextView textContainers = findViewById(R.id.numberOfContainers);

        textContainers.setText(String.valueOf(app.getNumberOfContainers()));

        Button addContainer = findViewById(R.id.addContainer);
        addContainer.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);
            }
        });
        //EMPTY CONTAINERS
        TextView textEmptyContainers = findViewById(R.id.emptyContainers);
        textEmptyContainers.setText(String.valueOf(app.getEmptyContainers()));
        //FULL CONTAINERS
        TextView textFullContainers = findViewById(R.id.fullContainers);
        textFullContainers.setText(String.valueOf(app.getFullContainers()));
        //LOW STOCK
        TextView textLowStockContainers = findViewById(R.id.lowStockContainers);
        textLowStockContainers.setText(String.valueOf(app.getLowStockContainers()));

        //INCOMING STOCK
        TextView textIncomingStock = findViewById(R.id.incomingStock);
        textIncomingStock.setText(String.valueOf(app.getWeightOfNotArrivedShipments())+"kg");
        //STOCK TO BE SOLD
        TextView textToBeSold = findViewById(R.id.stockToBeSold);
        textToBeSold.setText(String.valueOf(app.getWeightOfNotDoneSales())+"kg");
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(app.getUser().compareTo("manager")==0){
            getMenuInflater().inflate(R.menu.menu_warehouse_manager, menu);
        }
        else{
            getMenuInflater().inflate(R.menu.menu_warehouse_worker, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.home:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);

                return true;

            case R.id.shipments:
                intent = new Intent(getApplicationContext(), ShipmentsActivity.class);
                startActivity(intent);

                return true;

            case R.id.sales:
                intent = new Intent(getApplicationContext(), SalesActivity.class);
                startActivity(intent);

                return true;

            case R.id.inventory:
                intent = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(intent);
                finish();
                return true;

            case R.id.addContainer:
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);

                return true;

            case R.id.newShipment:
                intent = new Intent(getApplicationContext(), AddShipmentActivity.class);
                startActivity(intent);

                return true;

            case R.id.newSale:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);
                Toast.makeText(InventoryActivity.this,"Select a container to sell its contents",Toast.LENGTH_SHORT).show();
                return true;

            case R.id.graphs:
                intent = new Intent(getApplicationContext(), GraphsActivity.class);
                startActivity(intent);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
