package com.example.menuapp;

import android.annotation.SuppressLint;
import android.content.Context;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;


import java.util.ArrayList;

public class ListAdapterShipments extends ArrayAdapter<Shipment> {
    public ListAdapterShipments(@NonNull Context context, ArrayList<Shipment> data) {
        super(context, R.layout.shipment_list_item, data);
    }

    @SuppressLint("ResourceAsColor")
    @NonNull
    public View getView(int position, @Nullable View view, @NonNull ViewGroup parent) {
        Shipment shipment = getItem(position);

        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.shipment_list_item,parent,false);
        }

        ImageView listImage = view.findViewById(R.id.shipmentListImage);
        TextView productName = view.findViewById(R.id.shipmentListProductName);
        TextView companyName = view.findViewById(R.id.shipmentListCompanyName);
        TextView statusText = view.findViewById(R.id.shipmentStatus);
        TextView listDate = view.findViewById(R.id.shipmentDate);

        statusText.setText(shipment.getStatus());
        if(shipment.getStatus().compareTo("ARRIVED") == 0){
            listImage.setImageResource(R.drawable.ic_baseline_check_box_24);
            statusText.setTextColor(R.color.contrast_dark_red);
        }
        else{
            listImage.setImageResource(R.drawable.shipping);
            statusText.setTextColor(R.color.contrast_red);
        }

        productName.setText(shipment.getProduct());
        companyName.setText(shipment.getCompany());
        listDate.setText(shipment.getDateOfArrival());

        return view;
    }

}
