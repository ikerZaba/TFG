package com.example.menuapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ListAdapterContainers extends ArrayAdapter<Container> {

    public ListAdapterContainers(@NonNull Context context, ArrayList<Container> data) {
        super(context, R.layout.container_list_item, data);
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View view, @NonNull ViewGroup parent) {

        Container c = getItem(position);

        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.container_list_item, parent, false);
        }

        ImageView listImage = view.findViewById(R.id.listImage);
        TextView listName = view.findViewById(R.id.listName);
        TextView listDate = view.findViewById(R.id.listDate);

        //listImage.setImageResource(R.drawable.caja_azul);
        listName.setText(c.getCode() + ": " + c.getProduct());
        listDate.setText(c.getDateOfArrival());

        return view;
    }
}
