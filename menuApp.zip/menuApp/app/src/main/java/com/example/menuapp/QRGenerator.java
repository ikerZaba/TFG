package com.example.menuapp;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.google.zxing.BarcodeFormat;
import com.google.zxing.MultiFormatWriter;
import com.google.zxing.WriterException;
import com.google.zxing.common.BitMatrix;
import com.journeyapps.barcodescanner.BarcodeEncoder;

public class QRGenerator {

    public Bitmap generateQRCode(int shipmentID, String containerCode){
        MultiFormatWriter multiFormatWriter = new MultiFormatWriter();
        String information = "id: "+shipmentID+", container: "+containerCode;

        try {
            System.out.println("QR creation started...");
            BitMatrix bitMatrix = multiFormatWriter.encode(information, BarcodeFormat.QR_CODE, 300, 300);

            BarcodeEncoder barcodeEncoder = new BarcodeEncoder();
            Bitmap bitmap = barcodeEncoder.createBitmap(bitMatrix);
            System.out.println("QR successfully created");
            return bitmap;
        }catch (WriterException e){
            throw new RuntimeException(e);
        }
    }
}
