package com.example.menuapp;

import android.annotation.SuppressLint;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import java.util.ArrayList;

public class ListAdapterSales extends ArrayAdapter<Sale> {
    public ListAdapterSales(@NonNull Context context, ArrayList<Sale> data) {
        super(context, R.layout.sale_list_item, data);
    }

    @SuppressLint("ResourceAsColor")
    @NonNull
    public View getView(int position, @Nullable View view, @NonNull ViewGroup parent) {
        Sale sale = getItem(position);

        if (view == null) {
            view = LayoutInflater.from(getContext()).inflate(R.layout.sale_list_item,parent,false);
        }

        ImageView listImage = view.findViewById(R.id.saleListImage);
        TextView containerCode = view.findViewById(R.id.saleListContainerCode);
        TextView productName = view.findViewById(R.id.saleListProductName);
        TextView clientName = view.findViewById(R.id.saleListClientName);
        TextView statusText = view.findViewById(R.id.saleStatus);
        TextView listDate = view.findViewById(R.id.saleDate);

        statusText.setText(sale.getStatus());
        if(sale.getStatus().compareTo("DONE") == 0){
            listImage.setImageResource(R.drawable.ic_baseline_check_box_24);
            statusText.setTextColor(R.color.green);
        }
        else{
            listImage.setImageResource(R.drawable.ic_baseline_shopping_cart_24);
            statusText.setTextColor(R.color.red);
        }

        productName.setText(sale.getProduct());
        clientName.setText(sale.getClient());
        listDate.setText(sale.getDateOfSale());
        containerCode.setText(sale.getContainer());

        return view;
    }
}
