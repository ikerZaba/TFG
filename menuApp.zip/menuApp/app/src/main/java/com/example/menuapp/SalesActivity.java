package com.example.menuapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.menuapp.databinding.ActivitySalesLayoutBinding;

import java.util.ArrayList;

public class SalesActivity extends AppCompatActivity {
    private ActivitySalesLayoutBinding binding;
    ArrayAdapter<Sale> listAdapter;
    Aplication app;
    Intent intent;
    ArrayList<Sale> saleList;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_warehouse, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        System.out.println(item.getItemId());
        switch (item.getItemId()){

            case R.id.addContainer:
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);
                finish();
                return true;

            case R.id.home:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);
                finish();
                return true;

            case R.id.shipments:
                intent = new Intent(getApplicationContext(), ShipmentsActivity.class);
                startActivity(intent);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySalesLayoutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        app = (Aplication) getApplicationContext();
        saleList = app.getSalesList();

        listAdapter = new ListAdapterSales(this, saleList);
        binding.salesListView.setAdapter(listAdapter);
        binding.salesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(!app.getSalesList().isEmpty()){
                    Sale sale = app.getSalesList().get(position);
                    Bundle bundle = new Bundle();
                    bundle.putInt("_id",sale.get_id());
                    bundle.putString("container",sale.getContainer());
                    bundle.putString("product",sale.getProduct());
                    bundle.putString("client",sale.getClient());
                    bundle.putInt("weight",sale.getWeight());
                    bundle.putString("date",sale.getDateOfSale());
                    bundle.putString("status",sale.getStatus());
                    bundle.putInt("price",sale.getPrice());

                    Intent intent = new Intent(getApplicationContext(), SaleInfoActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });


        Button newSale = (Button) findViewById(R.id.buttonNewSale);
        newSale.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddSaleActivity.class);
                startActivity(intent);
            }
        });


    }
}
