package com.example.menuapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.menuapp.databinding.ActivitySalesLayoutBinding;

import java.util.ArrayList;

public class SalesActivity extends AppCompatActivity {
    private ActivitySalesLayoutBinding binding;
    ArrayAdapter<Sale> listAdapter;
    Aplication app;
    Intent intent;
    ArrayList<Sale> saleList;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(app.getUser().compareTo("manager")==0){
            getMenuInflater().inflate(R.menu.menu_warehouse_manager, menu);
        }
        else{
            getMenuInflater().inflate(R.menu.menu_warehouse_worker, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.home:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);

                return true;

            case R.id.shipments:
                intent = new Intent(getApplicationContext(), ShipmentsActivity.class);
                startActivity(intent);

                return true;

            case R.id.sales:
                intent = new Intent(getApplicationContext(), SalesActivity.class);
                startActivity(intent);
                finish();
                return true;

            case R.id.inventory:
                intent = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(intent);

                return true;

            case R.id.addContainer:
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);

                return true;

            case R.id.newShipment:
                intent = new Intent(getApplicationContext(), AddShipmentActivity.class);
                startActivity(intent);

                return true;

            case R.id.newSale:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);
                Toast.makeText(this,"Select a container to sell its contents",Toast.LENGTH_SHORT).show();
                return true;

            case R.id.graphs:
                intent = new Intent(getApplicationContext(), GraphsActivity.class);
                startActivity(intent);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivitySalesLayoutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        app = (Aplication) getApplicationContext();
        saleList = app.getSalesList();

        listAdapter = new ListAdapterSales(this, saleList);
        binding.salesListView.setAdapter(listAdapter);
        binding.salesListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(!app.getSalesList().isEmpty()){
                    Sale sale = app.getSalesList().get(position);
                    Bundle bundle = new Bundle();
                    bundle.putInt("_id",sale.get_id());
                    bundle.putString("container",sale.getContainer());
                    bundle.putString("product",sale.getProduct());
                    bundle.putString("client",sale.getClient());
                    bundle.putInt("weight",sale.getWeight());
                    bundle.putString("date",sale.getDateOfSale());
                    bundle.putString("status",sale.getStatus());
                    bundle.putInt("price",sale.getPrice());

                    Intent intent = new Intent(getApplicationContext(), SaleInfoActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });

    }

    public void sortSales(View view){
        Button sortButton = findViewById(R.id.buttonSortSales);
        String currentState = sortButton.getText().toString();
        //All->not arrived->arrived
        if(currentState.compareTo("All") == 0){
            saleList = app.getNotDoneSaleList();
            sortButton.setText("Not done");
        }
        else if(currentState.compareTo("Not done") == 0){
            saleList = app.getDoneSaleList();
            sortButton.setText("Done");
        }
        else{
            saleList = app.getSalesList();
            sortButton.setText("All");
        }

        listAdapter = new ListAdapterSales(this, saleList);
        binding.salesListView.setAdapter(listAdapter);
    }
}
