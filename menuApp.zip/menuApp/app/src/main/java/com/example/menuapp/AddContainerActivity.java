package com.example.menuapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.RadioButton;
import android.widget.Toast;

public class AddContainerActivity extends Activity {
    DBManager _manager;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addcontainer);
        _manager = new DBManager(this);

        ImageButton goback = findViewById(R.id.button6);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void addContainer(View view) {
        EditText textCorr = findViewById(R.id.editTextCorridorNumber);
        String stringCorridor = textCorr.getText().toString();

        if(stringCorridor.isEmpty()){
            Toast.makeText(this,"Please fill the number of the CORRIDOR",Toast.LENGTH_SHORT).show();
        }
        else{
            EditText textboxn = findViewById(R.id.editTextBoxNumber);
            String stringBoxNumber = textboxn.getText().toString();

            if(stringBoxNumber.isEmpty()){
                Toast.makeText(this,"Please fill the number of the BOX",Toast.LENGTH_SHORT).show();
            }
            else{
                EditText maxw = findViewById(R.id.editTextNumberMaxWeight);
                String maxWeight = maxw.getText().toString();

                if(maxWeight.isEmpty()){
                    Toast.makeText(this,"Please set a MAXIMUM WEIGHT for the container",Toast.LENGTH_SHORT).show();
                }
                else{
                    String side = "";
                    RadioButton left = findViewById(R.id.radioButtonLeft);
                    RadioButton right = findViewById(R.id.radioButtonRight);
                    if(left.isChecked()){
                        side ="L";
                    }
                    else if(right.isChecked()){
                        side = "R";
                    }
                    else{
                        Toast.makeText(this,"Please check the SIDE field",Toast.LENGTH_SHORT).show();
                    }
                    String code = stringCorridor+"-"+side+"-"+stringBoxNumber;
                    if(!_manager.addContainerDB(code,Integer.parseInt(maxWeight))){
                        Toast.makeText(this,"Database error, please try again",Toast.LENGTH_SHORT).show();
                    }
                    else{
                        Toast.makeText(this,"Container added to the list",Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(getApplicationContext(), Warehouse.class);
                        startActivity(intent);
                        finish();
                    }
                }
            }

        }

    }
}
