package com.example.menuapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class ShipmentInfoActivity extends Activity {
    Aplication app;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infoshipment);
        TextView label = (TextView) findViewById(R.id.textView);
        Bundle bundle = getIntent().getExtras();
        int shipmentID = bundle.getInt("_id");
        String product = bundle.getString("product");
        String company = bundle.getString("company");
        String dateOfArrival = bundle.getString("date");
        int weight = bundle.getInt("weight");
        String status = bundle.getString("status");

        label.setText("\nProduct:"+product);
        label.append("\nCompany:"+company);
        label.append("\nWeight: "+weight+"kg\n");
        label.append("\nDate of arrival: "+dateOfArrival);
        label.append("\nStatus: "+status);

        Button notify = (Button) findViewById(R.id.buttonNotifyArrival);
        notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(status.compareTo("delivered")!=0){
                    if(app.shipmentArrival(shipmentID)){
                        //Toast.makeText(this,"Shipment arrival successfully registered",Toast.LENGTH_SHORT).show();
                        //call FILL CONTAINER
                        finish();
                    }
                    else{
                        //Toast.makeText(this,"Unsuccessful, please try again",Toast.LENGTH_LONG).show();
                        finish();
                    }
                }
            }
        });

        Button goback = (Button) findViewById(R.id.button4);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
