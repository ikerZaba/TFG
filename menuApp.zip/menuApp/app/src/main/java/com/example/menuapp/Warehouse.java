package com.example.menuapp;

import android.content.Intent;
import android.os.Bundle;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.Toast;

import com.example.menuapp.databinding.ActivityWarehouseBinding;

import java.util.ArrayList;


public class Warehouse extends AppCompatActivity {

    private ActivityWarehouseBinding binding;
    ArrayAdapter<Container> todoItemsAdapter;
    Aplication app;
    Intent intent;
    ArrayList<Container> containerList;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(app.getUser().compareTo("manager")==0){
            getMenuInflater().inflate(R.menu.menu_warehouse_manager, menu);
        }
        else{
            getMenuInflater().inflate(R.menu.menu_warehouse_worker, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.home:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);
                finish();
                return true;

            case R.id.shipments:
                intent = new Intent(getApplicationContext(), ShipmentsActivity.class);
                startActivity(intent);

                return true;

            case R.id.sales:
                intent = new Intent(getApplicationContext(), SalesActivity.class);
                startActivity(intent);

                return true;

            case R.id.inventory:
                intent = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(intent);

                return true;

            case R.id.addContainer:
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);

                return true;

            case R.id.newShipment:
                intent = new Intent(getApplicationContext(), AddShipmentActivity.class);
                startActivity(intent);

                return true;

            case R.id.newSale:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);
                Toast.makeText(Warehouse.this,"Select a container to sell its contents",Toast.LENGTH_SHORT).show();
                return true;

            case R.id.graphs:
                intent = new Intent(getApplicationContext(), GraphsActivity.class);
                startActivity(intent);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWarehouseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        app = (Aplication) getApplicationContext();
        containerList = app.getContainerList();

        todoItemsAdapter = new ListAdapterContainers(this, containerList);
        binding.warehouseListView.setAdapter(todoItemsAdapter);
        binding.warehouseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Container container = app.getContainerList().get(position);
                Bundle bundle = new Bundle();
                bundle.putString("code",container.getCode());
                bundle.putInt("maxweight",container.getMaxWeight());
                bundle.putInt("currentweight",container.getCurrentWeight());
                if(container.getProduct()!=null) bundle.putString("content",container.getProduct());
                else bundle.putString("content","empty");

                Intent intent = new Intent(getApplicationContext(), ContainerInfoActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        ImageButton openScanner = findViewById(R.id.buttonScanQR);
        openScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), QRScannerActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            String code = bundle.getString("code");
            int maxWeight = bundle.getInt("maxweight");
            Container c = new Container(code, maxWeight);
            app.getContainerList().add(c);
            todoItemsAdapter.notifyDataSetChanged();
        }
    }
}