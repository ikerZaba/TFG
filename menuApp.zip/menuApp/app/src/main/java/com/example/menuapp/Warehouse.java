package com.example.menuapp;

import android.content.Intent;
import android.os.Bundle;


import com.example.menuapp.databinding.ActivityWarehouseBinding;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import java.util.ArrayList;


public class Warehouse extends AppCompatActivity {

    private ActivityWarehouseBinding binding;
    ArrayAdapter<Container> todoItemsAdapter;
    Aplication app;
    Intent intent;
    ArrayList<Container> containerList;
    QRScannerActivity scanner;


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_warehouse, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        System.out.println(item.getItemId());
        switch (item.getItemId()){

            case R.id.addContainer:
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);

                return true;

            case R.id.shipments:
                intent = new Intent(getApplicationContext(), ShipmentsActivity.class);
                startActivity(intent);

                return true;

            case R.id.sales:
                intent = new Intent(getApplicationContext(), SalesActivity.class);
                startActivity(intent);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityWarehouseBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        app = (Aplication) getApplicationContext();
        Toolbar toolbar = binding.toolbar;
        setSupportActionBar(toolbar);
        containerList = app.getContainerList();

        todoItemsAdapter = new ListAdapterContainers(this, containerList);
        binding.warehouseListView.setAdapter(todoItemsAdapter);
        binding.warehouseListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Container container = app.getContainerList().get(position);
                Bundle bundle = new Bundle();
                bundle.putString("code",container.getCode());
                bundle.putInt("maxweight",container.getMaxWeight());
                bundle.putInt("currentweight",container.getCurrentWeight());
                if(container.getProduct()!=null) bundle.putString("content",container.getProduct());
                else bundle.putString("content","empty");

                Intent intent = new Intent(getApplicationContext(), ContainerInfoActivity.class);
                intent.putExtras(bundle);
                startActivity(intent);
            }
        });

        Button openScanner = (Button) findViewById(R.id.buttonScanQR);
        openScanner.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), QRScannerActivity.class);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(resultCode == RESULT_OK) {
            Bundle bundle = data.getExtras();
            String code = bundle.getString("code");
            int maxWeight = bundle.getInt("maxweight");
            Container c = new Container(code, maxWeight);
            app.getContainerList().add(c);
            todoItemsAdapter.notifyDataSetChanged();
        }
    }
}