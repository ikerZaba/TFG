package com.example.menuapp;

import com.parse.ParseClassName;
import com.parse.ParseObject;

@ParseClassName("Product")
public class Product extends ParseObject{


    public Product(){ }

    public String getName() { return getString("name");}

    public String getType() {
        return getString("type");
    }

    public void setName(String name) {
        put("name",name);
    }

    public void setType(String type) {
        put("type",type);
    }

    public int getWeight() {return getInt("weight");}

    public void setWeight(int weight) {put("weight",weight);}

    @Override
    public String toString() {
        return this.getName()+", "+this.getType()+" "+this.getWeight()+"kg";
    }
}
