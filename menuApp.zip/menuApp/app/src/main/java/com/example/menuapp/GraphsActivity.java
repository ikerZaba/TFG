package com.example.menuapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.components.YAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.github.mikephil.charting.utils.ColorTemplate;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

public class GraphsActivity extends AppCompatActivity {
    Aplication app;
    Intent intent;
    PieChart shipmentsPieChart;
    PieChart salesPieChart;
    BarChart salesBarChart;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graphs);
        app = (Aplication) getApplicationContext();

        //SHIPMENTS PIE CHART
        shipmentsPieChart = findViewById(R.id.shipmentsPieChart);
        shipmentsPieChart.setUsePercentValues(false);
        shipmentsPieChart.setDrawHoleEnabled(false);
        shipmentsPieChart.getDescription().setEnabled(false);
        shipmentsPieChart.setDrawEntryLabels(false);

        ArrayList<PieEntry> yValuesShipments = new ArrayList<>();

        int arrivedShipments = app.getArrivedShipmentNumber();
        int pendingShipments = app.getNotArrivedShipmentNumber();

        yValuesShipments.add(new PieEntry(arrivedShipments,"Arrived"));
        yValuesShipments.add(new PieEntry(pendingShipments,"Not Arrived"));

        PieDataSet dataSetShipments = new PieDataSet(yValuesShipments, "SHIPMENTS");
        dataSetShipments.setColors(ColorTemplate.LIBERTY_COLORS);
        dataSetShipments.setDrawValues(true);

        shipmentsPieChart.setData(new PieData(dataSetShipments));

        //SALES PIE CHART
        salesPieChart = findViewById(R.id.salesPieChart);
        salesPieChart.setUsePercentValues(false);
        salesPieChart.setDrawHoleEnabled(false);
        salesPieChart.getDescription().setEnabled(false);
        salesPieChart.setDrawEntryLabels(false);

        ArrayList<PieEntry> yValuesSales = new ArrayList<>();

        int doneSales = app.getDoneSaleNumber();
        int pendingSales = app.getNotDoneSaleNumber();

        yValuesSales.add(new PieEntry(doneSales,"Done"));
        yValuesSales.add(new PieEntry(pendingSales,"Not Done"));

        PieDataSet dataSetSales = new PieDataSet(yValuesSales, "SALES");
        dataSetShipments.setColors(ColorTemplate.LIBERTY_COLORS);
        dataSetShipments.setDrawValues(true);

        salesPieChart.setData(new PieData(dataSetSales));

        //SALES BAR CHART
        salesBarChart = findViewById(R.id.salesBarChart);
        salesBarChart.getAxisRight().setDrawLabels(false);

        ArrayList<BarEntry> barEntries = new ArrayList<>();

        barEntries.add(new BarEntry(0,app.getSalesPerDayOfTheWeek(Calendar.MONDAY)));
        barEntries.add(new BarEntry(1,app.getSalesPerDayOfTheWeek(Calendar.TUESDAY)));
        barEntries.add(new BarEntry(2,app.getSalesPerDayOfTheWeek(Calendar.WEDNESDAY)));
        barEntries.add(new BarEntry(3,app.getSalesPerDayOfTheWeek(Calendar.THURSDAY)));
        barEntries.add(new BarEntry(4,app.getSalesPerDayOfTheWeek(Calendar.FRIDAY)));
        barEntries.add(new BarEntry(5,app.getSalesPerDayOfTheWeek(Calendar.SATURDAY)));

        salesBarChart.getAxisLeft().setAxisMaximum(20f);
        salesBarChart.getAxisLeft().setAxisMinimum(0f);
        salesBarChart.getAxisLeft().setAxisLineWidth(1f);
        salesBarChart.getAxisLeft().setAxisLineColor(R.color.black);
        salesBarChart.getAxisLeft().setLabelCount(4);

        List<String> xValues = Arrays.asList("Mon","Tue","Wed","Thu","Fri","Sat");
        salesBarChart.getXAxis().setValueFormatter(new IndexAxisValueFormatter(xValues));
        salesBarChart.getXAxis().setPosition(XAxis.XAxisPosition.BOTTOM);

        BarDataSet dataSet = new BarDataSet(barEntries,"Sales per day");
        dataSet.setColors(ColorTemplate.PASTEL_COLORS);

        salesBarChart.getDescription().setEnabled(false);
        salesBarChart.invalidate();
        salesBarChart.setData(new BarData(dataSet));

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        if(app.getUser().compareTo("manager")==0){
            getMenuInflater().inflate(R.menu.menu_warehouse_manager, menu);
        }
        else{
            getMenuInflater().inflate(R.menu.menu_warehouse_worker, menu);
        }
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){

            case R.id.home:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);

                return true;

            case R.id.shipments:
                intent = new Intent(getApplicationContext(), ShipmentsActivity.class);
                startActivity(intent);

                return true;

            case R.id.sales:
                intent = new Intent(getApplicationContext(), SalesActivity.class);
                startActivity(intent);

                return true;

            case R.id.inventory:
                intent = new Intent(getApplicationContext(), InventoryActivity.class);
                startActivity(intent);

                return true;

            case R.id.addContainer:
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);

                return true;

            case R.id.newShipment:
                intent = new Intent(getApplicationContext(), AddShipmentActivity.class);
                startActivity(intent);

                return true;

            case R.id.newSale:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);
                Toast.makeText(GraphsActivity.this,"Select a container to sell its contents",Toast.LENGTH_SHORT).show();
                return true;

            case R.id.graphs:
                intent = new Intent(getApplicationContext(), GraphsActivity.class);
                startActivity(intent);
                finish();
                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }
}
