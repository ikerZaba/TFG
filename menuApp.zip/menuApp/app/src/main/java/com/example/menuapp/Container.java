package com.example.menuapp;

public class Container {
    private String code;
    private String side;
    private int corridor;
    private int boxNumber;
    private int maxWeight;
    private int currentWeight;
    private String product;
    private String dateOfArrival;

    public Container(String code, int maxWeight) {
        this.code = code;
        String[] parts = code.split("-");
        this.side = parts[0];
        this.corridor = Integer.parseInt(parts[1]);
        this.boxNumber = Integer.parseInt(parts[2]);
        this.maxWeight = maxWeight;
        this.currentWeight = 0;
        this.product = "Empty";
        this.dateOfArrival = "-";
    }

    public Container(int corridor,String side, int boxNumber, String product, int currentWeight, int maxWeight,  String dateOfArrival) {
        this.code = corridor +"-"+side+"-"+ boxNumber;
        this.side = side;
        this.corridor = corridor;
        this.boxNumber = boxNumber;
        this.maxWeight = maxWeight;
        this.currentWeight = currentWeight;
        this.product = product;
        this.dateOfArrival = dateOfArrival;
    }

    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getSide() {
        return side;
    }

    public void setSide(String side) {
        this.side = side;
    }

    public int getCorridor() {
        return corridor;
    }

    public void setCorridor(int corridor) {
        this.corridor = corridor;
    }

    public int getBoxNumber() {
        return boxNumber;
    }

    public void setBoxNumber(int boxNumber) {
        this.boxNumber = boxNumber;
    }

    public int getMaxWeight() {
        return maxWeight;
    }

    public void setMaxWeight(int maxWeight) {
        this.maxWeight = maxWeight;
    }

    public int getCurrentWeight() {
        return currentWeight;
    }

    public void setCurrentWeight(int currentWeight) {
        this.currentWeight = currentWeight;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public String getDateOfArrival() {
        return dateOfArrival;
    }

    public void setDateOfArrival(String dateOfArrival) {
        this.dateOfArrival = dateOfArrival;
    }
}
