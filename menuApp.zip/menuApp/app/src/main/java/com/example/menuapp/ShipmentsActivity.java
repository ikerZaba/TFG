package com.example.menuapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.example.menuapp.databinding.ActivityShipmentsLayoutBinding;

import java.util.ArrayList;

public class ShipmentsActivity extends AppCompatActivity {
    private ActivityShipmentsLayoutBinding binding;
    ArrayAdapter<Shipment> listAdapter;
    Aplication app;
    Intent intent;
    ArrayList<Shipment> shipmentList;

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.menu_warehouse, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        System.out.println(item.getItemId());
        switch (item.getItemId()){

            case R.id.addContainer:
                intent = new Intent(getApplicationContext(), AddContainerActivity.class);
                startActivity(intent);
                finish();
                return true;

            case R.id.home:
                intent = new Intent(getApplicationContext(), Warehouse.class);
                startActivity(intent);
                finish();
                return true;

            case R.id.sales:
                intent = new Intent(getApplicationContext(), SalesActivity.class);
                startActivity(intent);

                return true;

            default:
                return super.onOptionsItemSelected(item);
        }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityShipmentsLayoutBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        app = (Aplication) getApplicationContext();
        shipmentList = app.getShipmentList();

        listAdapter = new ListAdapterShipments(this, shipmentList);
        binding.shipmentListView.setAdapter(listAdapter);
        binding.shipmentListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if(!app.getShipmentList().isEmpty()){
                    Shipment shipment = app.getShipmentList().get(position);
                    Bundle bundle = new Bundle();
                    bundle.putInt("_id",shipment.get_id());
                    bundle.putString("product",shipment.getProduct());
                    bundle.putString("company",shipment.getCompany());
                    bundle.putInt("weight",shipment.getWeight());
                    bundle.putString("date",shipment.getDateOfArrival());
                    bundle.putString("status",shipment.getStatus());

                    Intent intent = new Intent(getApplicationContext(), ShipmentInfoActivity.class);
                    intent.putExtras(bundle);
                    startActivity(intent);
                }
            }
        });


        Button newShipment = (Button) findViewById(R.id.buttonNewShipment);
        newShipment.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(), AddShipmentActivity.class);
                startActivity(intent);
            }
        });


    }
}
