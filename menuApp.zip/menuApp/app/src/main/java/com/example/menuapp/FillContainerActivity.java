package com.example.menuapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class FillContainerActivity extends Activity {
    Aplication app;
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fillcontainer);
        app = (Aplication) getApplicationContext();
        Button goback = (Button) findViewById(R.id.button5);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void fillCode(View view) {
        EditText editText = (EditText) findViewById(R.id.editTextContainerCodeFill);
        String code = editText.getText().toString();
        editText = (EditText) findViewById(R.id.editTextProductName);
        String name = editText.getText().toString();
        editText = (EditText) findViewById(R.id.editTextProductQuantityFill);
        String quant = editText.getText().toString();
        int quantity = Integer.parseInt(quant);
        for (Container c : app.getContainerList()){
            if(c.getCode().equals(code)){
                if(name.equals(c.getProduct())){
                    c.setCurrentWeight(c.getCurrentWeight()+quantity);
                }
                else{
                    c.setProduct(name);
                    c.setCurrentWeight(quantity);
                }

                if(c.getCurrentWeight()>c.getMaxWeight()){
                    c.setMaxWeight(c.getCurrentWeight());
                }
                break;
            }
        }
        Intent intent = new Intent(view.getContext(),Warehouse.class);
        startActivity(intent);
        finish();
    }
}
