package com.example.menuapp;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class FillContainerActivity extends Activity {
    Aplication app;
    QRGenerator qrGenerator = new QRGenerator();
    PDFGenerator pdfGenerator = new PDFGenerator();
    int _idShipment;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_fillcontainer);
        app = (Aplication) getApplicationContext();
        Bundle bundle = getIntent().getExtras();
        _idShipment = bundle.getInt("_id");

        Button goback = (Button) findViewById(R.id.button5);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void fillContainer(View view){
        Shipment shipment = app.searchShipmentDB(_idShipment);
        try {
            String containerCode = app.findContainerAndFill(shipment);
            System.out.println("Code: "+containerCode);
            if(!containerCode.isEmpty()){
                System.out.println("Registering shipment arrival");
                if(app.shipmentArrival(_idShipment)){
                    System.out.println("QRGenerator call");
                    Bitmap bitmap = qrGenerator.generateQRCode(_idShipment,containerCode);
                    try{
                        pdfGenerator.generatePDF(bitmap,shipment,containerCode);

                        Toast.makeText(this,"PDF successfully downloaded",Toast.LENGTH_LONG).show();

                        Intent intent = new Intent(getApplicationContext(), Warehouse.class);
                        startActivity(intent);
                        finish();
                    } catch (Exception e) {
                        Toast.makeText(this,"PDF creation ERROR",Toast.LENGTH_SHORT).show();
                        System.out.println("PDF creation ERROR");
                        app.errorShipment(_idShipment);
                    }
                }
                else{
                    Toast.makeText(this,"Error in the update of the shipment",Toast.LENGTH_SHORT).show();
                    System.out.println("Error in the update of the shipment");
                    app.emptyContainer(containerCode,shipment.getWeight());
                    app.errorShipment(_idShipment);
                }
            }
            else{
                Toast.makeText(this,"No container available",Toast.LENGTH_SHORT).show();
                System.out.println("No container available");
            }
        }catch (RuntimeException e){
            Toast.makeText(this,"Data base error",Toast.LENGTH_SHORT).show();
            e.printStackTrace();
            app.errorShipment(_idShipment);
        }

    }
}
