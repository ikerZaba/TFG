package com.example.menuapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

public class DBManager {

    private DBConnection _connection;
    private SQLiteDatabase _myDataBase;

    public DBManager(Context context) {
        _connection = new DBConnection(context);
    }

    public DBManager openWrite() throws SQLException {
        _myDataBase = _connection.getWritableDatabase();
        return this;
    }

    public DBManager openRead() throws SQLException {
        _myDataBase = _connection.getReadableDatabase();
        return this;
    }

    public void close(){
        _connection.close();
    }


    //TABLE CONTAINERS
    public static final String TABLE_CONTAINERS = "containers";
    public static final String CONTAINER_CODE = "code";
    public static final String CONTAINER_PRODUCT = "product";
    public static final String CONTAINER_CURRENT_WEIGHT = "currentW";
    public static final String CONTAINER_MAX_WEIGHT = "maxW";
    public static final String CONTAINER_DATE = "dateOfArrival";

    public static final String TABLE_CONTAINERS_CREATE =
            "create table containers(code TEXT primary key, product TEXT, currentW INTEGER, maxW INTEGER, dateOfArrival TEXT)";

    public static final String TABLE_CONTAINERS_DROP = "drop table if exists "+TABLE_CONTAINERS;

    public boolean addContainerDB(String code, int maxWeight){
        this.openWrite();
        ContentValues values = new ContentValues();
        values.put(CONTAINER_CODE, code);
        values.put(CONTAINER_PRODUCT, "empty");
        values.put(CONTAINER_CURRENT_WEIGHT, 0);
        values.put(CONTAINER_MAX_WEIGHT, maxWeight);
        values.put(CONTAINER_DATE, "-");

        if(_myDataBase.insert(TABLE_CONTAINERS,null,values) ==-1){
            System.out.println("ERROR IN THE INSERTION");
            this.close();
            return false;
        }
        System.out.println("SUCCESSFUL INSERTION");
        //this.close();
        return true;
    }

    public ArrayList<Container> getContainerListDB(){
        this.openRead();
        ArrayList<Container> result = new ArrayList<>();
        String code,side,product,dateOfArrival;
        int corridor,boxN,maxW,currentW;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            code = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_CODE));
            String[] codeParts = code.split("-");
            corridor = Integer.parseInt(codeParts[0]);
            side = codeParts[1];
            boxN = Integer.parseInt(codeParts[2]);
            maxW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_MAX_WEIGHT));
            currentW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_CURRENT_WEIGHT));
            product = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_PRODUCT));
            dateOfArrival = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_DATE));

            result.add(new Container(corridor,side,boxN,product,currentW,maxW,dateOfArrival));
        }
        //this.close();
        return result;
    }

    public int getNumberOfContainersDB() {
        int number = 0;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            number++;
        }
        return number;
    }

    public int getEmptyContainersDB(){
        int number = 0;
        int currentW;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            currentW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_CURRENT_WEIGHT));
            if(currentW==0){
                number++;
            }
        }
        return number;
    }

    public int getLowStockContainersDB(){
        int number = 0;
        int currentW;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            currentW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_CURRENT_WEIGHT));
            if(currentW<20){
                number++;
            }
        }
        return number;
    }

    public int getFullContainersDB(){
        int number = 0;
        int currentW,maxW;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            currentW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_CURRENT_WEIGHT));
            maxW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_MAX_WEIGHT));
            if(currentW==maxW){
                number++;
            }
        }
        return number;
    }

    public Container getContainerByCodeDB(String codeToSearch){
        Container container = null;
        String code,side,product,dateOfArrival;
        int corridor,boxN,maxW,currentW;
        Boolean found = false;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(!found && cursor.moveToNext()){
            code = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_CODE));
            System.out.println(code);
            if(code.compareTo(codeToSearch) == 0){
                String[] codeParts = code.split("-");
                corridor = Integer.parseInt(codeParts[0]);
                side = codeParts[1];
                boxN = Integer.parseInt(codeParts[2]);
                maxW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_MAX_WEIGHT));
                currentW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_CURRENT_WEIGHT));
                product = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_PRODUCT));
                dateOfArrival = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_DATE));

                container = new Container(corridor,side,boxN,product,currentW,maxW,dateOfArrival);
                System.out.println("FOUND");
                found = true;
            }
        }
        return container;
    }

    public int emptyContainerDB(String codeToSearch, int soldWeight) {
        String code;
        int currentW = 0;
        Boolean found = false;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(!found && cursor.moveToNext()){
            code = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_CODE));
            System.out.println(code);
            if(code.compareTo(codeToSearch) == 0){
                currentW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_CURRENT_WEIGHT));
                found = true;
            }
        }

        if(found){
            currentW = currentW-soldWeight;
            if(currentW<0){
                return 2;
            }
            ContentValues values = new ContentValues();
            values.put(CONTAINER_CURRENT_WEIGHT, currentW);

            String selection = CONTAINER_CODE + " = ?";
            String[] selectionArgs = { codeToSearch };

            int count = _myDataBase.update(TABLE_CONTAINERS,values,selection,selectionArgs);
            System.out.println("CONTAINER updated");
            //this.close();
            return count-1;
        }
        else return 1;

    }

    public int getWarehouseSpaceDB() {
        this.openRead();
        int result = 0;
        int maxW;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            maxW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_MAX_WEIGHT));
            result += maxW;
        }
        //this.close();
        return result;
    }

    public int getOccupiedWarehouseSpaceDB() {
        this.openRead();
        int result = 0;
        int currentW;

        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            currentW = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_CURRENT_WEIGHT));
            result += currentW;
        }
        //this.close();
        return result;
    }


    //TABLE SHIPMENTS
    public static final String TABLE_SHIPMENTS = "shipments";
    public static final String SHIPMENT_ID = "_id";
    public static final String SHIPMENT_DATE = "dateOfArrival";
    public static final String SHIPMENT_PRODUCT = "product";
    public static final String SHIPMENT_WEIGHT = "weight";
    public static final String SHIPMENT_COMPANY = "company";
    public static final String SHIPMENT_STATUS = "status";


    public static final String TABLE_SHIPMENTS_CREATE =
            "create table shipments(_id INTEGER primary key, status TEXT,product TEXT, weight INTEGER, company TEXT, dateOfArrival TEXT)";
    public static final String TABLE_SHIPMENTS_DROP = "drop table if exists "+TABLE_SHIPMENTS;

    private int generateShipmentIdDB(){
        this.openRead();
        int result = 0;
        Cursor cursor = _myDataBase.query(TABLE_SHIPMENTS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            result++;
        }
        //this.close();
        return result;
    }

    public boolean addShipmentDB(String date, String product, String company, int weight){
        this.openWrite();
        ContentValues values = new ContentValues();
        int _id = generateShipmentIdDB();
        values.put(SHIPMENT_ID, _id);
        values.put(SHIPMENT_STATUS, "not arrived");
        values.put(SHIPMENT_WEIGHT, weight);
        values.put(SHIPMENT_PRODUCT, product);
        values.put(SHIPMENT_COMPANY, company);
        values.put(SHIPMENT_DATE, date);

        if(_myDataBase.insert(TABLE_SHIPMENTS,null,values) ==-1){
            System.out.println("ERROR IN THE INSERTION");
            this.close();
            return false;
        }
        System.out.println("SUCCESSFUL INSERTION");
        //this.close();
        return true;
    }

    public ArrayList<Shipment> getShipmentListDB(){
        this.openRead();
        ArrayList<Shipment> result = new ArrayList<>();
        String status,product,dateOfArrival,company;
        int _id,weight;

        Cursor cursor = _myDataBase.query(TABLE_SHIPMENTS,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            _id = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_ID));
            dateOfArrival = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_DATE));
            product = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_PRODUCT));
            weight = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_WEIGHT));
            company = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_COMPANY));
            status = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_STATUS));
            result.add(new Shipment(_id,dateOfArrival,product,weight,company,status));
        }
        //this.close();
        return result;
    }

    public ArrayList<Shipment> getNotArrivedShipmentListDB() {
        this.openRead();
        ArrayList<Shipment> result = new ArrayList<>();
        String status,product,dateOfArrival,company;
        int _id,weight;

        String selection = SHIPMENT_STATUS + " = ?";
        String[] selectionArgs = { "not arrived" };

        Cursor cursor = _myDataBase.query(TABLE_SHIPMENTS,
                null,selection,selectionArgs,null,null,null);

        while(cursor.moveToNext()){
            _id = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_ID));
            dateOfArrival = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_DATE));
            product = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_PRODUCT));
            weight = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_WEIGHT));
            company = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_COMPANY));
            status = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_STATUS));
            result.add(new Shipment(_id,dateOfArrival,product,weight,company,status));
        }
        //this.close();
        return result;
    }

    public ArrayList<Shipment> getArrivedShipmentListDB() {
        this.openRead();
        ArrayList<Shipment> result = new ArrayList<>();
        String status,product,dateOfArrival,company;
        int _id,weight;

        String selection = SHIPMENT_STATUS + " = ?";
        String[] selectionArgs = { "ARRIVED" };

        Cursor cursor = _myDataBase.query(TABLE_SHIPMENTS,
                null,selection,selectionArgs,null,null,null);

        while(cursor.moveToNext()){
            _id = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_ID));
            dateOfArrival = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_DATE));
            product = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_PRODUCT));
            weight = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_WEIGHT));
            company = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_COMPANY));
            status = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_STATUS));
            result.add(new Shipment(_id,dateOfArrival,product,weight,company,status));
        }
        //this.close();
        return result;
    }

    public Shipment searchShipmentDB(int idToSearch){
        this.openRead();
        String status="",product="",dateOfArrival="",company="";
        int weight=0,_id=0;
        Boolean found = false;
        Cursor cursor = _myDataBase.query(TABLE_SHIPMENTS,
                null,null,null,null,null,null);

        while(!found && cursor.moveToNext()){
            _id = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_ID));
            if(_id == idToSearch){
                dateOfArrival = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_DATE));
                product = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_PRODUCT));
                weight = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_WEIGHT));
                company = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_COMPANY));
                status = cursor.getString(cursor.getColumnIndexOrThrow(SHIPMENT_STATUS));
                found = true;
            }

        }
        return new Shipment(_id,dateOfArrival,product,weight,company,status);
    }

    public boolean shipmentArrivalDB(int shipmentID){
        this.openWrite();
        String newStatus = "ARRIVED";
        ContentValues values = new ContentValues();
        values.put(SHIPMENT_STATUS, newStatus);

        String selection = SHIPMENT_ID + " = ?";
        String[] selectionArgs = { String.valueOf(shipmentID) };

        int count = _myDataBase.update(TABLE_SHIPMENTS,values,selection,selectionArgs);
        System.out.println("SHIPMENT STATUS changed");
        //this.close();
        return count==1;
    }

    public String findContainerToFillDB(Shipment shipment){
        String code = "",containerProduct;
        int currentWeight = 0,maxWeight;
        Boolean success = false;
        Cursor cursor = _myDataBase.query(TABLE_CONTAINERS,
                null,null,null,null,null,null);

        while(!success && cursor.moveToNext()){
            containerProduct = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_PRODUCT));
            if((containerProduct.compareTo("empty")==0) || (containerProduct.compareTo(shipment.getProduct())==0)){
                maxWeight = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_MAX_WEIGHT));
                currentWeight = cursor.getInt(cursor.getColumnIndexOrThrow(CONTAINER_CURRENT_WEIGHT));
                if(shipment.getWeight()<=(maxWeight-currentWeight)){
                    code = cursor.getString(cursor.getColumnIndexOrThrow(CONTAINER_CODE));
                    success = true;
                }
            }
        }
        if(success){
            ContentValues values = new ContentValues();
            values.put(CONTAINER_CURRENT_WEIGHT, currentWeight+shipment.getWeight());
            values.put(CONTAINER_PRODUCT, shipment.getProduct());
            values.put(CONTAINER_DATE, shipment.getDateOfArrival());

            String selection = CONTAINER_CODE + " = ?";
            String[] selectionArgs = { code };

            int count = _myDataBase.update(TABLE_CONTAINERS,values,selection,selectionArgs);
            if(count==1){
                return code;
            }
        }
        return "";
    }

    public void errorShipmentDB(int shipmentID) {
        this.openWrite();
        String newStatus = "not arrived";
        ContentValues values = new ContentValues();
        values.put(SHIPMENT_STATUS, newStatus);

        String selection = SHIPMENT_ID + " = ?";
        String[] selectionArgs = { String.valueOf(shipmentID) };

        _myDataBase.update(TABLE_SHIPMENTS,values,selection,selectionArgs);
        System.out.println("SHIPMENT STATUS changed");
        //this.close();
    }

    public int getWeightOfNotArrivedShipmentsDB() {
        this.openRead();
        int result = 0;
        int weight;

        String selection = SHIPMENT_STATUS + " = ?";
        String[] selectionArgs = { "not arrived" };

        Cursor cursor = _myDataBase.query(TABLE_SHIPMENTS,
                null,selection,selectionArgs,null,null,null);

        while(cursor.moveToNext()){
            weight = cursor.getInt(cursor.getColumnIndexOrThrow(SHIPMENT_WEIGHT));
            result += weight;
        }
        //this.close();
        return result;
    }


    //TABLE SALES
    public static final String TABLE_SALES = "sales";
    public static final String SALE_ID = "_id";
    public static final String SALE_DATE = "dateOfSale";
    public static final String SALE_CONTAINER_CODE = "container";
    public static final String SALE_PRODUCT = "product";
    public static final String SALE_WEIGHT = "weight";
    public static final String SALE_CLIENT = "client";
    public static final String SALE_STATUS = "status";
    public static final String SALE_PRICE = "price";

    public static final String TABLE_SALES_CREATE =
            "create table sales(_id INTEGER primary key, status TEXT,container TEXT, product TEXT, weight INTEGER, dateOfSale TEXT, client TEXT, price INTEGER)";
    public static final String TABLE_SALES_DROP = "drop table if exists "+TABLE_SALES;

    private int generateSaleIdDB(){
        this.openRead();
        int result = 0;
        Cursor cursor = _myDataBase.query(TABLE_SALES,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            result++;
        }
        //this.close();
        return result;
    }

    public int addSaleDB(String containerCode, String date, String product, String client, int weight, int price){
        this.openWrite();

        Container container = getContainerByCodeDB(containerCode);

        if(container.getProduct().compareTo(product)!=0){
            return 1;
        }

        if(container.getCurrentWeight()<weight){
            return 2;
        }
        ContentValues values = new ContentValues();
        values.put(SALE_ID, generateSaleIdDB());
        values.put(SALE_CONTAINER_CODE, containerCode);
        values.put(SALE_PRODUCT, product);
        values.put(SALE_WEIGHT, weight);
        values.put(SALE_DATE, date);
        values.put(SALE_CLIENT, client);
        values.put(SALE_STATUS, "not done");
        values.put(SALE_PRICE, price);

        if(_myDataBase.insert(TABLE_SALES,null,values) ==-1){
            System.out.println("ERROR IN THE INSERTION");
            this.close();
            return 3;
        }
        System.out.println("SUCCESSFUL INSERTION");
        //this.close();
        return 0;
    }

    public ArrayList<Sale> getSaleListDB(){
        this.openRead();
        ArrayList<Sale> result = new ArrayList<>();
        String container,status,product,dateOfSale,company;
        int _id,weight,price;

        Cursor cursor = _myDataBase.query(TABLE_SALES,
                null,null,null,null,null,null);

        while(cursor.moveToNext()){
            _id = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_ID));
            dateOfSale = cursor.getString(cursor.getColumnIndexOrThrow(SALE_DATE));
            container = cursor.getString(cursor.getColumnIndexOrThrow(SALE_CONTAINER_CODE));
            product = cursor.getString(cursor.getColumnIndexOrThrow(SALE_PRODUCT));
            weight = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_WEIGHT));
            company = cursor.getString(cursor.getColumnIndexOrThrow(SALE_CLIENT));
            status = cursor.getString(cursor.getColumnIndexOrThrow(SALE_STATUS));
            price = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_PRICE));
            result.add(new Sale(_id,dateOfSale,container,product,weight,company,status,price));
        }
        //this.close();
        return result;
    }


    public ArrayList<Sale> getNotDoneSaleListDB() {
        this.openRead();
        ArrayList<Sale> result = new ArrayList<>();
        String container,status,product,dateOfSale,company;
        int _id,weight,price;

        String selection = SALE_STATUS + " = ?";
        String[] selectionArgs = { "not done" };

        Cursor cursor = _myDataBase.query(TABLE_SALES,
                null,selection,selectionArgs,null,null,null);

        while(cursor.moveToNext()){
            _id = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_ID));
            dateOfSale = cursor.getString(cursor.getColumnIndexOrThrow(SALE_DATE));
            container = cursor.getString(cursor.getColumnIndexOrThrow(SALE_CONTAINER_CODE));
            product = cursor.getString(cursor.getColumnIndexOrThrow(SALE_PRODUCT));
            weight = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_WEIGHT));
            company = cursor.getString(cursor.getColumnIndexOrThrow(SALE_CLIENT));
            status = cursor.getString(cursor.getColumnIndexOrThrow(SALE_STATUS));
            price = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_PRICE));
            result.add(new Sale(_id,dateOfSale,container,product,weight,company,status,price));
        }
        //this.close();
        return result;
    }

    public ArrayList<Sale> getDoneSaleListDB() {
        this.openRead();
        ArrayList<Sale> result = new ArrayList<>();
        String container,status,product,dateOfSale,company;
        int _id,weight,price;

        String selection = SALE_STATUS + " = ?";
        String[] selectionArgs = { "DONE" };

        Cursor cursor = _myDataBase.query(TABLE_SALES,
                null,selection,selectionArgs,null,null,null);

        while(cursor.moveToNext()){
            _id = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_ID));
            dateOfSale = cursor.getString(cursor.getColumnIndexOrThrow(SALE_DATE));
            container = cursor.getString(cursor.getColumnIndexOrThrow(SALE_CONTAINER_CODE));
            product = cursor.getString(cursor.getColumnIndexOrThrow(SALE_PRODUCT));
            weight = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_WEIGHT));
            company = cursor.getString(cursor.getColumnIndexOrThrow(SALE_CLIENT));
            status = cursor.getString(cursor.getColumnIndexOrThrow(SALE_STATUS));
            price = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_PRICE));
            result.add(new Sale(_id,dateOfSale,container,product,weight,company,status,price));
        }
        //this.close();
        return result;
    }

    public int getWeightOfNotDoneSalesDB() {
        this.openRead();
        int result = 0;
        int weight;

        String selection = SALE_STATUS + " = ?";
        String[] selectionArgs = { "not done" };

        Cursor cursor = _myDataBase.query(TABLE_SALES,
                null,selection,selectionArgs,null,null,null);

        while(cursor.moveToNext()){
            weight = cursor.getInt(cursor.getColumnIndexOrThrow(SALE_WEIGHT));
            result += weight;
        }
        //this.close();
        return result;
    }

    public boolean saleRegisterDB(int saleID){
        this.openWrite();
        String newStatus = "DONE";
        ContentValues values = new ContentValues();
        values.put(SALE_STATUS, newStatus);

        String selection = SALE_ID + " = ?";
        String[] selectionArgs = { String.valueOf(saleID) };

        int count = _myDataBase.update(TABLE_SALES,values,selection,selectionArgs);

        //this.close();
        return count==1;
    }

    public float getSalesPerDayOfTheWeekDB(int dayOfWeek) {
        this.openRead();
        float result = 0;
        String dateOfSale;
        LocalDate date;

        String selection = SALE_STATUS + " = ?";
        String[] selectionArgs = { "DONE" };

        Cursor cursor = _myDataBase.query(TABLE_SALES,
                null,selection,selectionArgs,null,null,null);

        while(cursor.moveToNext()){
            dateOfSale = cursor.getString(cursor.getColumnIndexOrThrow(SALE_DATE));
            //dd/mm/yyyy hh:mm
            String[] parts = dateOfSale.split(" ");
            date = LocalDate.parse(parts[0]);
            if(date.getDayOfWeek().getValue() == dayOfWeek){
                result += 1;
            }
        }
        //this.close();
        return result;
    }

    public void errorSaleDB(int saleID) {
        this.openWrite();
        String newStatus = "not done";
        ContentValues values = new ContentValues();
        values.put(SALE_STATUS, newStatus);

        String selection = SALE_ID + " = ?";
        String[] selectionArgs = { String.valueOf(saleID) };

        _myDataBase.update(TABLE_SALES,values,selection,selectionArgs);

        //this.close();
    }


    //TABLE USERS
    /*public static final String TABLE_USERS = "users";
    public static final String USER_NAME = "username";
    public static final String USER_PASSWORD = "password";

    public static final String TABLE_USERS_CREATE =
            "create table users(username TEXT primary key, password TEXT)";
    public static final String TABLE_USERS_DROP = "drop table if exists "+TABLE_USERS;


    public boolean insertUsersDB(){

    }*/

    public boolean checkPasswordDB(String passwd) {
        return passwd.compareTo("admin") == 0;
    }
}
