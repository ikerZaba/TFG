package com.example.menuapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

import java.util.ArrayList;

public class DBConnection extends SQLiteOpenHelper {

    public static final String DB_NAME = "Warehouse";
    public static final int DB_VERSION = 22;

    public DBConnection(Context context) {
        super(context, DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase myDataBase) {
        myDataBase.execSQL(DBManager.TABLE_CONTAINERS_CREATE);
        myDataBase.execSQL(DBManager.TABLE_SHIPMENTS_CREATE);
        myDataBase.execSQL(DBManager.TABLE_SALES_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase myDatabase, int i, int i1) {
        myDatabase.execSQL(DBManager.TABLE_CONTAINERS_DROP);
        myDatabase.execSQL(DBManager.TABLE_SHIPMENTS_DROP);
        myDatabase.execSQL(DBManager.TABLE_SALES_DROP);

        myDatabase.execSQL(DBManager.TABLE_CONTAINERS_CREATE);//esto no debería estar aqui
        myDatabase.execSQL(DBManager.TABLE_SHIPMENTS_CREATE);
        myDatabase.execSQL(DBManager.TABLE_SALES_CREATE);
    }
}
