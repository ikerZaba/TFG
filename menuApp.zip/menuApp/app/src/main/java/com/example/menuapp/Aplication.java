package com.example.menuapp;

import android.app.Application;

import java.util.ArrayList;

import com.parse.Parse;
import com.parse.ParseObject;

public class Aplication extends Application {
    DBManager _manager;

    ArrayList<Container> containerList;
    ArrayList<Shipment> shipmentList;
    ArrayList<Sale> salesList;
    ArrayList<Product> productList;

    @Override
    public void onCreate() {
        super.onCreate();
        _manager = new DBManager(this);
        containerList = new ArrayList<>();
        productList = new ArrayList<>();
        ParseObject.registerSubclass(Product.class);
        Parse.initialize(new Parse.Configuration.Builder(getApplicationContext())
                .applicationId("myAppId")
                .clientKey("empty")
                .server("https://lab6ar.herokuapp.com/parse/")
                        .build());

    }

    public ArrayList<Container> getContainerList() {
        return _manager.getContainerListDB();
    }

    public ArrayList<Shipment> getShipmentList() { return _manager.getShipmentListDB();}

    public ArrayList<Sale> getSalesList() { return _manager.getSaleListDB();}

    public ArrayList<Product> getProductList() {
        return productList;
    }

    public boolean shipmentArrival(int shipmentID) {
        return _manager.shipmentArrivalDB(shipmentID);
    }

    public boolean saleRegister(int saleID){
        return _manager.saleRegisterDB(saleID);
    }
}