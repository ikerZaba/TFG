package com.example.menuapp;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class ContainerInfoActivity extends Activity {

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infocontainer);
        TextView label = (TextView) findViewById(R.id.textView);
        Bundle bundle = getIntent().getExtras();
        String containerCode = bundle.getString("code");
        String[] codeParts = containerCode.split("-");
        int currentweight = bundle.getInt("currentweight");
        int maxweight = bundle.getInt("maxweight");
        String product = bundle.getString("content");

        label.setText("Container: "+containerCode);
        label.append("\nLOCATION");
        label.append("\nCorridor: "+codeParts[0]);
        if(codeParts[1].compareTo("L")==0){
            label.append("\nSide: Left");
        }
        else{
            label.append("\nSide: Right");
        }
        label.append("\nBox number: "+codeParts[2]);
        label.append("\n\nCONTENT");
        label.append("\nProduct: "+product+"");
        label.append("\nCurrent weight: "+currentweight+"/"+maxweight+"kg\n");


        Button goback = (Button) findViewById(R.id.button4);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
