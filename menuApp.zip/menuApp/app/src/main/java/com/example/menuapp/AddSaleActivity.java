package com.example.menuapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AddSaleActivity extends Activity {
    DBManager _manager;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addsale);
        _manager = new DBManager(this);

        Button goback = (Button) findViewById(R.id.button6);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void addSale(View view) {
        EditText editTextDate = findViewById(R.id.editTextDateOfSale);
        String stringDate = editTextDate.getText().toString();

        if (stringDate.isEmpty()) {
            Toast.makeText(this, "Please fill the date of the transaction", Toast.LENGTH_SHORT).show();
        } else {
            EditText editTextContainerCode = findViewById(R.id.editTextContainerCode);
            String stringContainer = editTextContainerCode.getText().toString();

            if (stringContainer.isEmpty()) {
                Toast.makeText(this, "Please fill the code of the container", Toast.LENGTH_SHORT).show();
            } else {
                EditText editTextProductName = findViewById(R.id.editTextProductName);
                String stringProduct = editTextProductName.getText().toString();

                if (stringProduct.isEmpty()) {
                    Toast.makeText(this, "Please fill the name of the product", Toast.LENGTH_SHORT).show();
                } else {
                    EditText editTextClientName = findViewById(R.id.editTextCompanyName);
                    String stringClient = editTextClientName.getText().toString();

                    if (stringClient.isEmpty()) {
                        Toast.makeText(this, "Please fill the name of the client", Toast.LENGTH_SHORT).show();
                    } else {
                        EditText editTextWeight = findViewById(R.id.editTextWeight);
                        String stringWeight = editTextWeight.getText().toString();

                        if (stringWeight.isEmpty()) {
                            Toast.makeText(this, "Please fill the weight", Toast.LENGTH_SHORT).show();
                        } else {
                            EditText editTextPrice = findViewById(R.id.editTextPrice);
                            String stringPrice = editTextPrice.getText().toString();

                            if (stringPrice.isEmpty()) {
                                Toast.makeText(this, "Please fill the price", Toast.LENGTH_SHORT).show();
                            } else {
                                if (!_manager.addSaleDB(stringContainer,stringDate, stringProduct,
                                        stringClient, Integer.parseInt(stringWeight),
                                        Integer.parseInt(stringPrice))) {
                                    Toast.makeText(this, "Database error, please try again", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(this, "Shipment added to the list", Toast.LENGTH_SHORT).show();
                                    Intent intent = new Intent(getApplicationContext(), ShipmentsActivity.class);
                                    startActivity(intent);
                                    finish();
                                }
                            }

                        }
                    }

                }

            }
            }

    }
}
