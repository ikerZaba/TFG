package com.example.menuapp;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TimePicker;
import android.widget.Toast;

import java.util.Calendar;
import java.util.Locale;

public class AddSaleActivity extends Activity {
    DBManager _manager;
    String containerCode;
    String product;
    int hour;
    int minute;
    int year;
    int month;
    int day;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_addsale);
        _manager = new DBManager(this);
        Bundle bundle = getIntent().getExtras();
        containerCode = bundle.getString("containerCode");
        product = bundle.getString("product");

        EditText editTextContainerCode = findViewById(R.id.editTextContainerCode);
        editTextContainerCode.setText(containerCode);
        editTextContainerCode.setEnabled(false);

        EditText editTextProductName = findViewById(R.id.editTextProductName);
        editTextProductName.setText(product);
        editTextProductName.setEnabled(false);

        EditText editTextDate = findViewById(R.id.editTextDateOfSale);
        editTextDate.setEnabled(false);
        ImageButton dateButton = findViewById(R.id.buttonDate);
        dateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                day = calendar.get(Calendar.DAY_OF_MONTH);

                DatePickerDialog dialog;
                dialog = new DatePickerDialog(AddSaleActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int pYear, int pickedMonth, int pickedDay) {
                        year = pYear;
                        month = pickedMonth;
                        day = pickedDay;

                        editTextDate.setText(year+"/"+month+"/"+day);
                    }
                },year,month,day);
                dialog.show();
            }
        });

        EditText editTextTime = findViewById(R.id.editTextTimeOfSale);
        editTextTime.setEnabled(false);
        ImageButton timeButton = findViewById(R.id.buttonTime);
        timeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Calendar calendar = Calendar.getInstance();
                hour = calendar.get(Calendar.HOUR_OF_DAY);
                minute = calendar.get(Calendar.MINUTE);

                TimePickerDialog dialog;
                dialog = new TimePickerDialog(AddSaleActivity.this, new TimePickerDialog.OnTimeSetListener() {
                    @Override
                    public void onTimeSet(TimePicker timePicker, int hourOfDay, int minuteOfHour) {
                        hour = hourOfDay;
                        minute = minuteOfHour;

                        editTextTime.setText(String.format(Locale.getDefault(),"%d:%d",hour,minute));
                    }
                },hour,minute,true);
                dialog.show();
            }
        });

        ImageButton goback =findViewById(R.id.button6);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }

    public void addSale(View view) {
        EditText editTextDate = findViewById(R.id.editTextDateOfSale);
        String stringDate = editTextDate.getText().toString();
        EditText editTextTime = findViewById(R.id.editTextTimeOfSale);
        String stringTime = editTextTime.getText().toString();

        if (stringDate.isEmpty()||stringTime.isEmpty()) {
            Toast.makeText(this, "Please fill the date and time of the transaction", Toast.LENGTH_SHORT).show();
        } else {
            EditText editTextClientName = findViewById(R.id.editTextCompanyName);
            String stringClient = editTextClientName.getText().toString();

            if (stringClient.isEmpty()) {
                Toast.makeText(this, "Please fill the name of the client", Toast.LENGTH_SHORT).show();
            } else {
                EditText editTextWeight = findViewById(R.id.editTextWeight);
                String stringWeight = editTextWeight.getText().toString();

                if (stringWeight.isEmpty()) {
                    Toast.makeText(this, "Please fill the weight", Toast.LENGTH_SHORT).show();
                } else {
                    EditText editTextPrice = findViewById(R.id.editTextPrice);
                    String stringPrice = editTextPrice.getText().toString();

                    if (stringPrice.isEmpty()) {
                        Toast.makeText(this, "Please fill the price", Toast.LENGTH_SHORT).show();
                    } else {
                        int addSaleResult = _manager.addSaleDB(containerCode,stringDate+" "+stringTime, product,
                                stringClient, Integer.parseInt(stringWeight),
                                Integer.parseInt(stringPrice));
                        switch (addSaleResult){
                            case 1:
                                Toast.makeText(this, "The container contains a different product", Toast.LENGTH_LONG).show();
                                break;
                            case 2:
                                Toast.makeText(this, "Not enough product in the container", Toast.LENGTH_LONG).show();
                                break;
                            case 3:
                                 Toast.makeText(this, "Database error, please try again", Toast.LENGTH_LONG).show();
                                 break;

                            case 0:
                                Toast.makeText(this, "Sale added to the list", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(getApplicationContext(), SalesActivity.class);
                                startActivity(intent);
                                finish();
                        }

                    }

                }
            }

        }

    }
}

