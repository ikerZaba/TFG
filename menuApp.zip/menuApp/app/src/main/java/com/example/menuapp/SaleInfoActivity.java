package com.example.menuapp;

import android.app.Activity;
import android.app.Application;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SaleInfoActivity extends Activity {
    Aplication app;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_infosale);
        TextView label = (TextView) findViewById(R.id.textView);
        Bundle bundle = getIntent().getExtras();
        int saleID = bundle.getInt("_id");
        String container = bundle.getString("container");
        String product = bundle.getString("product");
        String client = bundle.getString("client");
        String dateOfTransaction = bundle.getString("date");
        int weight = bundle.getInt("weight");
        String status = bundle.getString("status");
        int price = bundle.getInt("price");

        label.setText("\nFrom container code:"+container);
        label.append("\nProduct:"+product);
        label.append("\nCompany:"+client);
        label.append("\nWeight taken: "+weight+"kg\n");
        label.append("\nDate of transaction: "+dateOfTransaction);
        label.append("\nPrice of transaction: "+price+"€");
        label.append("\nStatus: "+status);

        Button notify = (Button) findViewById(R.id.buttonTransactionDone);
        notify.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(status.compareTo("delivered")!=0){
                    if(app.saleRegister(saleID)){
                        //Toast.makeText(this,"Shipment arrival successfully registered",Toast.LENGTH_SHORT).show();
                        //call EMPTY CONTAINER
                        finish();
                    }
                    else{
                        //Toast.makeText(this,"Unsuccessful, please try again",Toast.LENGTH_LONG).show();
                        finish();
                    }
                }
            }
        });

        Button goback = (Button) findViewById(R.id.button4);
        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });
    }
}
