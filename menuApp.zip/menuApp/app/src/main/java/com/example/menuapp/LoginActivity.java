package com.example.menuapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends Activity {
    Aplication app;
    TextView passText;
    EditText editTextPasswd;

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        app = (Aplication) getApplicationContext();
        passText = findViewById(R.id.textViewPasswd);
        editTextPasswd = findViewById(R.id.loginPasswd);

        passText.setEnabled(false);
        editTextPasswd.setEnabled(false);
    }

    public void login(View view){
        RadioButton buttonWorker = findViewById(R.id.radioButtonWorker);
        RadioButton buttonManager = findViewById(R.id.radioButtonManager);

        if(buttonManager.isChecked()){
            if(!passText.isEnabled()&&!editTextPasswd.isEnabled()){
                passText.setEnabled(true);
                editTextPasswd.setEnabled(true);
            }
            else{
                String passwd = editTextPasswd.getText().toString();
                if(passwd.isEmpty()){
                    Toast.makeText(this,"Fill the password please",Toast.LENGTH_SHORT).show();
                }
                else{
                    if(app.checkPassword(passwd)){
                        app.setUser("manager");
                    }
                    else{
                        Toast.makeText(this,"Incorrect password, try again",Toast.LENGTH_SHORT).show();
                    }
                }
            }
        }
        else if(buttonWorker.isChecked()){
            app.setUser("worker");
        }
        else{
            Toast.makeText(this,"Select a user please",Toast.LENGTH_SHORT).show();
        }

        if(!app.getUser().isEmpty()){
            Intent intent = new Intent(getApplicationContext(), Warehouse.class);
            startActivity(intent);
            finish();
        }
    }
}
